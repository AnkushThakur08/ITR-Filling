export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'user' | 'admin' | 'superadmin';
  createdAt: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  setUser: (user: User | null) => void;
  setLoading: (isLoading: boolean) => void;
  setError: (error: string | null) => void;
  logout: () => void;
}

export interface LoginFormData {
  phone: string;
  otp: string;
}

export interface SignupFormData {
  name: string;
  email: string;
  phone: string;
  otp: string;
}

export interface OtpVerificationData {
  phone: string;
  otp: string;
}