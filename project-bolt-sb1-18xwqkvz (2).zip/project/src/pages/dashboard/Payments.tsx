import React from 'react';
import { Card, Table, Tag, Button, Statistic, Row, Col, message, Empty, Alert } from 'antd';
import { motion } from 'framer-motion';
import { Download, CreditCard, TrendingUp, ReceiptIndianRupee, IndianRupee } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout';

interface PaymentsProps {
  darkMode: boolean;
  toggleTheme: () => void;
}

const Payments: React.FC<PaymentsProps> = ({ darkMode, toggleTheme }) => {
  const paymentHistory = [
    {
      id: '1',
      date: '2024-03-15',
      amount: 1499,
      status: 'Completed',
      description: 'ITR 2 Filing Fee',
      paymentMethod: 'Credit Card'
    },
    {
      id: '2',
      date: '2024-02-10',
      amount: 299,
      status: 'Completed',
      description: 'Document Verification',
      paymentMethod: 'UPI'
    }
  ];

  const handleDownloadInvoice = (id: string) => {
    message.success('Downloading invoice...');
  };

  const handleDownloadAllInvoices = () => {
    message.success('Downloading all invoices...');
  };

  const handlePayment = () => {
    // Implement payment logic
    message.success('Redirecting to payment gateway...');
  };

  const columns = [
    {
      title: 'Date',
      dataIndex: 'date',
      key: 'date',
      render: (text: string) => new Date(text).toLocaleDateString()
    },
    {
      title: 'Description',
      dataIndex: 'description',
      key: 'description'
    },
    {
      title: 'Amount',
      dataIndex: 'amount',
      key: 'amount',
      render: (amount: number) => (
        <div className="flex items-center">
          <IndianRupee size={14} className="mr-1" />
          {amount.toLocaleString()}
        </div>
      )
    },
    {
      title: 'Payment Method',
      dataIndex: 'paymentMethod',
      key: 'paymentMethod',
      render: (method: string) => (
        <Tag color={method === 'Credit Card' ? 'blue' : 'green'}>
          {method}
        </Tag>
      )
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status: string) => (
        <Tag color={status === 'Completed' ? 'success' : 'processing'}>
          {status}
        </Tag>
      )
    },
    {
      title: 'Action',
      key: 'action',
      render: (record: any) => (
        <Button 
          type="link" 
          icon={<Download size={16} />}
          onClick={() => handleDownloadInvoice(record.id)}
        >
          Download
        </Button>
      )
    }
  ];

  // Check if payment is pending
  const isPaymentPending = true; // This would come from your state/context

  return (
    <DashboardLayout darkMode={darkMode} toggleTheme={toggleTheme} title="Payments">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4 md:p-8"
      >
        <div className="max-w-6xl mx-auto lg:ml-64 px-4">
          {isPaymentPending && (
            <Alert
              message="Complete Your Payment"
              description="To begin processing your ITR, please complete the payment. Our team will start working on your return as soon as the payment is received."
              type="warning"
              showIcon
              action={
                <Button type="primary" size="large" onClick={handlePayment}>
                  Pay Now
                </Button>
              }
              className="mb-8"
            />
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="shadow-md">
              <Statistic
                title={<span className="text-lg">Total Paid</span>}
                value={1798}
                prefix={<IndianRupee size={24} className="mr-2 text-blue-500" />}
                valueStyle={{ color: '#0EA5E9' }}
              />
              <div className="mt-2 flex items-center text-green-500">
                <TrendingUp size={16} className="mr-1" />
                <span className="text-sm">All payments completed</span>
              </div>
            </Card>

            <Card className="shadow-md">
              <Statistic
                title={<span className="text-lg">Last Payment</span>}
                value={1499}
                prefix={<IndianRupee size={24} className="mr-2 text-blue-500" />}
                valueStyle={{ color: '#0EA5E9' }}
              />
              <div className="mt-2 flex items-center text-blue-500">
                <CreditCard size={16} className="mr-1" />
                <span className="text-sm">Via Credit Card</span>
              </div>
            </Card>

            <Card className="shadow-md">
              <Statistic
                title={<span className="text-lg">Total Invoices</span>}
                value={2}
                suffix={
                  <ReceiptIndianRupee 
                    size={24} 
                    className="ml-2 text-purple-500" 
                  />
                }
                valueStyle={{ color: '#0EA5E9' }}
              />
              <div className="mt-2 flex items-center text-purple-500">
                <Download size={16} className="mr-1" />
                <span className="text-sm">Available for download</span>
              </div>
            </Card>
          </div>

          <Card 
            title={
              <div className="flex items-center space-x-2">
                <ReceiptIndianRupee size={20} className="text-blue-500" />
                <span>Payment History</span>
              </div>
            }
            className="shadow-md"
            extra={
              <Button 
                type="primary" 
                icon={<Download size={16} />}
                onClick={handleDownloadAllInvoices}
              >
                Download All
              </Button>
            }
          >
            <div className="overflow-x-auto">
              <Table 
                columns={columns} 
                dataSource={paymentHistory}
                pagination={false}
                scroll={{ x: true }}
                locale={{
                  emptyText: (
                    <Empty
                      image={Empty.PRESENTED_IMAGE_SIMPLE}
                      description="No payment history available"
                    />
                  )
                }}
              />
            </div>
          </Card>
        </div>
      </motion.div>
    </DashboardLayout>
  );
};

export default Payments;