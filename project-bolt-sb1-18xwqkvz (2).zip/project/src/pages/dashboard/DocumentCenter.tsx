import React, { useState } from 'react';
import { Card, Upload, Button, List, Tag, Space, message, Empty } from 'antd';
import { motion } from 'framer-motion';
import { UploadCloud, FileText, Trash2, Download, AlertCircle } from 'lucide-react';
import type { UploadFile, UploadProps } from 'antd/es/upload/interface';
import DashboardLayout from '../../components/DashboardLayout';

interface DocumentCenterProps {
  darkMode: boolean;
  toggleTheme: () => void;
}

const DocumentCenter: React.FC<DocumentCenterProps> = ({ darkMode, toggleTheme }) => {
  const [fileList, setFileList] = useState<UploadFile[]>([
    {
      uid: '1',
      name: 'Form16.pdf',
      status: 'done',
      type: 'application/pdf',
    },
    {
      uid: '2',
      name: 'BankStatement.pdf',
      status: 'done',
      type: 'application/pdf',
    }
  ]);

  const documentTypes = [
    {
      title: 'Form 16',
      description: 'Annual salary statement from your employer',
      required: true,
      icon: <FileText className="h-8 w-8 text-blue-500" />
    },
    {
      title: 'Bank Statement',
      description: 'Statement showing your income and expenses',
      required: true,
      icon: <FileText className="h-8 w-8 text-blue-500" />
    },
    {
      title: 'Investment Proofs',
      description: 'Documents showing your investments and tax-saving instruments',
      required: false,
      icon: <FileText className="h-8 w-8 text-blue-500" />
    }
  ];

  const handleDownload = (file: UploadFile) => {
    message.success(`Downloading ${file.name}`);
  };

  const handleDelete = (file: UploadFile) => {
    setFileList(prev => prev.filter(f => f.uid !== file.uid));
    message.success(`${file.name} deleted successfully`);
  };

  const uploadProps: UploadProps = {
    name: 'file',
    multiple: true,
    action: '/api/upload',
    onChange(info) {
      const { status } = info.file;
      if (status === 'done') {
        message.success(`${info.file.name} file uploaded successfully.`);
        setFileList(prev => [...prev, info.file]);
      } else if (status === 'error') {
        message.error(`${info.file.name} file upload failed.`);
      }
    },
    beforeUpload(file) {
      const isValidType = ['application/pdf', 'image/jpeg', 'image/png'].includes(file.type);
      if (!isValidType) {
        message.error('You can only upload PDF, JPG, or PNG files!');
      }
      return isValidType || Upload.LIST_IGNORE;
    },
    maxCount: 5,
    showUploadList: false
  };

  return (
    <DashboardLayout darkMode={darkMode} toggleTheme={toggleTheme} title="Document Center">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4 md:p-8"
      >
        <div className="max-w-6xl mx-auto lg:ml-64 px-4">
          <div className="grid grid-cols-1 gap-6">
            {/* Upload Section */}
            <Card title="Required Documents" className="shadow-md order-2 lg:order-1">
              <div className="space-y-6">
                {documentTypes.map((doc, index) => (
                  <div key={index} className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                    <div className="flex items-start space-x-4">
                      <div className="flex-shrink-0">
                        {doc.icon}
                      </div>
                      <div className="flex-grow">
                        <div className="flex items-center justify-between">
                          <h3 className="text-lg font-medium">{doc.title}</h3>
                          {doc.required && (
                            <Tag color="red">Required</Tag>
                          )}
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                          {doc.description}
                        </p>
                        <Upload {...uploadProps} className="mt-3">
                          <Button 
                            type="primary" 
                            icon={<UploadCloud size={16} />}
                            className="w-full md:w-auto mt-4"
                          >
                            Upload {doc.title}
                          </Button>
                        </Upload>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Uploaded Files Section */}
            <Card 
              title="Uploaded Documents" 
              className="shadow-md order-1 lg:order-2"
            >
              {fileList.length > 0 ? (
                <div className="space-y-4">
                  {fileList.map(file => (
                    <div 
                      key={file.uid}
                      className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg"
                    >
                      <div className="flex items-center space-x-3">
                        <FileText className="h-6 w-6 text-blue-500" />
                        <div>
                          <p className="font-medium">{file.name}</p>
                          <p className="text-sm text-gray-500">
                            Uploaded on {new Date().toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button 
                          type="text" 
                          icon={<Download size={16} />}
                          onClick={() => handleDownload(file)}
                        />
                        <Button 
                          type="text" 
                          danger
                          icon={<Trash2 size={16} />}
                          onClick={() => handleDelete(file)}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <Empty
                  image={Empty.PRESENTED_IMAGE_SIMPLE}
                  description="No documents uploaded yet"
                />
              )}
            </Card>
          </div>
        </div>
      </motion.div>
    </DashboardLayout>
  );
};

export default DocumentCenter;