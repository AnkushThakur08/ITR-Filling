import React from 'react';
import { Layout, Menu, Card, Steps, Button, Table, Tag, Space, Alert } from 'antd';
import { motion } from 'framer-motion';
import { 
  FileText, 
  CreditCard, 
  CheckCircle,
  Clock,
  AlertCircle,
  Download,
  ArrowRight
} from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout';
import { useNavigate } from 'react-router-dom';

import "./style.css"

interface DashboardProps {
  darkMode: boolean;
  toggleTheme: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ darkMode, toggleTheme }) => {
   const navigate = useNavigate();
  const itrStatus = "In Progress"; // This would come from your backend
  const currentStep = 2; // This would be dynamic based on progress
  const hasCompletedPayment = false; // This would come from your backend


  const steps = [
    { title: 'Submitted', status: 'finish', icon: <FileText size={16} /> },
    { title: 'Verified', status: 'finish', icon: <CheckCircle size={16} /> },
    { title: 'Payment', status: 'wait', icon: <CheckCircle size={16} /> },
    { title: 'Processing', status: 'wait', icon: <Clock size={16} /> },
    { title: 'Filed', status: 'wait', icon: <FileText size={16} /> },
    { title: 'Done', status: 'wait', icon: <CheckCircle size={16} /> }
  ];

  const paymentHistory = [
    {
      id: '1',
      date: '2024-03-15',
      amount: 1499,
      status: 'Completed',
      description: 'ITR 2 Filing Fee'
    }
  ];

    const handlePayNow = () => {
    navigate('/dashboard/payments');
  };

  const columns = [
    {
      title: 'Date',
      dataIndex: 'date',
      key: 'date',
      render: (text: string) => new Date(text).toLocaleDateString()
    },
    {
      title: 'Description',
      dataIndex: 'description',
      key: 'description'
    },
    {
      title: 'Amount',
      dataIndex: 'amount',
      key: 'amount',
      render: (amount: number) => `₹${amount}`
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status: string) => (
        <Tag color={status === 'Completed' ? 'success' : 'processing'}>
          {status}
        </Tag>
      )
    },
    {
      title: 'Action',
      key: 'action',
      render: () => (
        <Button 
          type="link" 
          icon={<Download size={16} />}
          onClick={() => {/* Handle invoice download */}}
        >
          Download Invoice
        </Button>
      )
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Completed':
        return <CheckCircle className="h-8 w-8 text-green-500" />;
      case 'In Progress':
        return <Clock className="h-8 w-8 text-blue-500" />;
      default:
        return <AlertCircle className="h-8 w-8 text-yellow-500" />;
    }
  };

  return (
    <DashboardLayout darkMode={darkMode} toggleTheme={toggleTheme} title="Dashboard">
      <div className="p-8">
        <div className="max-w-6xl mx-auto lg:ml-64 px-4">
                    {!hasCompletedPayment ? (
            <Alert
              message="Complete Your Payment"
              description="To begin processing your ITR, please complete the payment. Our team will start working on your return as soon as the payment is received."
              type="warning"
              showIcon
              action={
                <Button 
                  type="primary" 
                  size="large" 
                  onClick={handlePayNow}
                  icon={<ArrowRight className="h-5 w-5" />}
                >
                  Pay Now
                </Button>
              }
              className="mb-8"
            />
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8"
            >
              <Card className="shadow-md">
                <div className="flex items-center space-x-4">
                  {getStatusIcon(itrStatus)}
                  <div>
                    <h3 className="text-lg font-medium">ITR Status</h3>
                    <p className="text-gray-600 dark:text-gray-400">{itrStatus}</p>
                  </div>
                </div>
              </Card>
              
              <Card className="shadow-md">
                <div className="flex items-center space-x-4">
                  <FileText className="h-8 w-8 text-blue-500" />
                  <div>
                    <h3 className="text-lg font-medium">ITR Type</h3>
                    <p className="text-gray-600 dark:text-gray-400">ITR 2</p>
                  </div>
                </div>
              </Card>
              
              <Card className="shadow-md">
                <div className="flex items-center space-x-4">
                  <CreditCard className="h-8 w-8 text-blue-500" />
                  <div>
                    <h3 className="text-lg font-medium">Amount Paid</h3>
                    <p className="text-gray-600 dark:text-gray-400">₹1,499</p>
                  </div>
                </div>
              </Card>
            </motion.div>
          )}

          <Card title="Filing Progress" className="mb-8 shadow-md">
            <Steps
              current={currentStep}
              items={steps.map(step => ({
                title: step.title,
                status: step.status,
                icon: step.icon
              }))}
              className="px-4 custom-class"
            />
          </Card>

          <Card title="Recent Payments" className="shadow-md">
            <div className="overflow-x-auto">
              <Table 
                columns={columns} 
                dataSource={paymentHistory}
                pagination={false}
                scroll={{ x: true }}
              />
            </div>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Dashboard;