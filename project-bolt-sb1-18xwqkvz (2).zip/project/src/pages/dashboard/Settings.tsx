import React, { useState } from 'react';
import { Card, Form, Switch, Radio, Button, Divider, message } from 'antd';
import { motion } from 'framer-motion';
import { Bell, Mail, Lock, Shield, Globe } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout';

interface SettingsProps {
  darkMode: boolean;
  toggleTheme: () => void;
}

const Settings: React.FC<SettingsProps> = ({ darkMode, toggleTheme }) => {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);

  const handleSave = async (values: any) => {
    setLoading(true);
    try {
      // Implement settings save logic here
      await new Promise(resolve => setTimeout(resolve, 1000));
      message.success('Settings saved successfully');
    } catch (error) {
      message.error('Failed to save settings');
    } finally {
      setLoading(false);
    }
  };

  return (
    <DashboardLayout darkMode={darkMode} toggleTheme={toggleTheme} title="Settings">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4 md:p-8"
      >
        <div className="max-w-6xl mx-auto lg:ml-64 px-4">
          <Form
            form={form}
            layout="vertical"
            onFinish={handleSave}
            initialValues={{
              notifications: true,
              emailUpdates: 'weekly',
              twoFactor: false,
              language: 'en'
            }}
          >
            <Card title="Notifications" className="mb-8 shadow-md">
              <div className="space-y-6">
                <Form.Item
                  name="notifications"
                  label={
                    <div className="flex items-center gap-2">
                      <Bell size={18} />
                      <span>Push Notifications</span>
                    </div>
                  }
                >
                  <Switch />
                </Form.Item>
                
                <Form.Item
                  name="emailUpdates"
                  label={
                    <div className="flex items-center gap-2">
                      <Mail size={18} />
                      <span>Email Updates</span>
                    </div>
                  }
                >
                  <Radio.Group>
                    <Radio value="daily">Daily</Radio>
                    <Radio value="weekly">Weekly</Radio>
                    <Radio value="monthly">Monthly</Radio>
                    <Radio value="never">Never</Radio>
                  </Radio.Group>
                </Form.Item>
              </div>
            </Card>

            <Card title="Security" className="mb-8 shadow-md">
              <div className="space-y-6">
                <Form.Item
                  name="twoFactor"
                  label={
                    <div className="flex items-center gap-2">
                      <Lock size={18} />
                      <span>Two-Factor Authentication</span>
                    </div>
                  }
                >
                  <Switch />
                </Form.Item>

                <Button
                  icon={<Shield size={18} />}
                  type="default"
                  className="w-full md:w-auto"
                >
                  Change Password
                </Button>
              </div>
            </Card>

            <Card title="Preferences" className="mb-8 shadow-md">
              <Form.Item
                name="language"
                label={
                  <div className="flex items-center gap-2">
                    <Globe size={18} />
                    <span>Language</span>
                  </div>
                }
              >
                <Radio.Group>
                  <Radio value="en">English</Radio>
                  <Radio value="hi">Hindi</Radio>
                </Radio.Group>
              </Form.Item>
            </Card>

            <div className="flex justify-end">
              <Button
                type="primary"
                htmlType="submit"
                loading={loading}
                size="large"
              >
                Save Changes
              </Button>
            </div>
          </Form>
        </div>
      </motion.div>
    </DashboardLayout>
  );
};

export default Settings;