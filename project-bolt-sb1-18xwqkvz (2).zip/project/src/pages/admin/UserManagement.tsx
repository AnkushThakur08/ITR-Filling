import React, { useState } from 'react';
import { Table, Card, Button, Tag, Input, Select, Modal, Form, message, Space, Dropdown } from 'antd';
import { motion } from 'framer-motion';
import { Search, UserPlus, Edit2, Trash2, Mail, Phone, Calendar, FileText, User, Download, Filter } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import AdminLayout from '../../components/AdminLayout';
import * as XLSX from 'xlsx';

interface UserManagementProps {
  darkMode: boolean;
  toggleTheme: () => void;
}

const UserManagement: React.FC<UserManagementProps> = ({ darkMode, toggleTheme }) => {
  const navigate = useNavigate();
  const [searchText, setSearchText] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterJourney, setFilterJourney] = useState('all');
  const [filterAssigned, setFilterAssigned] = useState('all');
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [editingUser, setEditingUser] = useState<any>(null);
  const [form] = Form.useForm();

  // Mock admin list
  const adminList = [
    { value: 'rahul', label: 'Rahul Matta' },
    { value: 'akshay', label: 'Akshay Singh' },
    { value: 'ankush', label: 'Ankush Thakur' },
    { value: 'yash', label: 'Yash Matta' }
  ];

  // Mock data - replace with actual API calls
  const users = [
  {
    id: '1',
    name: 'John Doe',
    email: 'john@example.com',
    phone: '+91 9876543210',
    status: 'inProgress',
    itrType: 'ITR-1',
    registrationDate: '2024-03-15',
    lastLogin: '2024-03-20',
    currentStep: 3,
    assignedTo: 'rahul'
  },
  {
    id: '2',
    name: 'Jane Smith',
    email: 'jane@example.com',
    phone: '+91 9876543211',
    status: 'pendingOnClient',
    itrType: 'ITR-2',
    registrationDate: '2024-03-14',
    lastLogin: '2024-03-19',
    currentStep: 2,
    assignedTo: 'akshay'
  },
  {
    id: '3',
    name: 'Rohit Sharma',
    email: 'rohit@example.com',
    phone: '+91 9876543212',
    status: 'filed',
    itrType: 'ITR-3',
    registrationDate: '2024-02-10',
    lastLogin: '2024-03-05',
    currentStep: 5,
    assignedTo: 'ankush'
  },
  {
    id: '4',
    name: 'Priya Mehta',
    email: 'priya@example.com',
    phone: '+91 9876543213',
    status: 'blocked',
    itrType: 'ITR-1',
    registrationDate: '2024-01-20',
    lastLogin: '2024-02-15',
    currentStep: 1,
    assignedTo: 'yash'
  },
  {
    id: '5',
    name: 'Aman Verma',
    email: 'aman@example.com',
    phone: '+91 9876543214',
    status: 'pendingOnClient',
    itrType: 'ITR-4',
    registrationDate: '2024-04-01',
    lastLogin: '2024-04-03',
    currentStep: 4,
    assignedTo: 'rahul'
  },
  {
    id: '6',
    name: 'Neha Agarwal',
    email: 'neha@example.com',
    phone: '+91 9876543215',
    status: 'paymentPending',
    itrType: 'ITR-2',
    registrationDate: '2024-03-10',
    lastLogin: '2024-03-17',
    currentStep: 2,
    assignedTo: 'akshay'
  },
  {
    id: '7',
    name: 'Siddharth Jain',
    email: 'sid@example.com',
    phone: '+91 9876543216',
    status: 'filed',
    itrType: 'ITR-1',
    registrationDate: '2024-02-25',
    lastLogin: '2024-03-01',
    currentStep: 5,
    assignedTo: 'ankush'
  },
  {
    id: '8',
    name: 'Anjali Rao',
    email: 'anjali@example.com',
    phone: '+91 9876543217',
    status: 'pending',
    itrType: 'ITR-3',
    registrationDate: '2024-03-12',
    lastLogin: '2024-03-16',
    currentStep: 1,
    assignedTo: 'yash'
  },
  {
    id: '9',
    name: 'Varun Kapoor',
    email: 'varun@example.com',
    phone: '+91 9876543218',
    status: 'blocked',
    itrType: 'ITR-4',
    registrationDate: '2024-01-15',
    lastLogin: '2024-02-10',
    currentStep: 3,
    assignedTo: 'rahul'
  },
  {
    id: '10',
    name: 'Meera Nair',
    email: 'meera@example.com',
    phone: '+91 9876543219',
    status: 'pendingOnClient',
    itrType: 'ITR-2',
    registrationDate: '2024-03-28',
    lastLogin: '2024-04-01',
    currentStep: 4,
    assignedTo: 'akshay'
  },
  {
    id: '11',
    name: 'Arjun Singh',
    email: 'arjun@example.com',
    phone: '+91 9876543220',
    status: 'inProgress',
    itrType: 'ITR-1',
    registrationDate: '2024-03-05',
    lastLogin: '2024-03-15',
    currentStep: 3,
    assignedTo: 'ankush'
  },
  {
    id: '12',
    name: 'Kritika Malhotra',
    email: 'kritika@example.com',
    phone: '+91 9876543221',
    status: 'paymentPending',
    itrType: 'ITR-3',
    registrationDate: '2024-02-08',
    lastLogin: '2024-02-28',
    currentStep: 5,
    assignedTo: 'yash'
  },
  {
    id: '13',
    name: 'Nikhil Joshi',
    email: 'nikhil@example.com',
    phone: '+91 9876543222',
    status: 'pending',
    itrType: 'ITR-2',
    registrationDate: '2024-04-02',
    lastLogin: '2024-04-05',
    currentStep: 2,
    assignedTo: 'rahul'
  },
  {
    id: '14',
    name: 'Sneha Kapoor',
    email: 'sneha@example.com',
    phone: '+91 9876543223',
    status: 'paymentPending',
    itrType: 'ITR-4',
    registrationDate: '2024-01-18',
    lastLogin: '2024-02-20',
    currentStep: 1,
    assignedTo: 'akshay'
  },
  {
    id: '15',
    name: 'Vivek Anand',
    email: 'vivek@example.com',
    phone: '+91 9876543224',
    status: 'pending',
    itrType: 'ITR-1',
    registrationDate: '2024-03-21',
    lastLogin: '2024-03-30',
    currentStep: 4,
    assignedTo: 'ankush'
  },
  {
    id: '16',
    name: 'Deepa Reddy',
    email: 'deepa@example.com',
    phone: '+91 9876543225',
    status: 'filed',
    itrType: 'ITR-2',
    registrationDate: '2024-02-19',
    lastLogin: '2024-03-06',
    currentStep: 5,
    assignedTo: 'yash'
  },
  {
    id: '17',
    name: 'Karan Mehta',
    email: 'karan@example.com',
    phone: '+91 9876543226',
    status: 'inProgress',
    itrType: 'ITR-3',
    registrationDate: '2024-03-09',
    lastLogin: '2024-03-13',
    currentStep: 3,
    assignedTo: 'rahul'
  },
  {
    id: '18',
    name: 'Pooja Sharma',
    email: 'pooja@example.com',
    phone: '+91 9876543227',
    status: 'paymentPending',
    itrType: 'ITR-4',
    registrationDate: '2024-03-25',
    lastLogin: '2024-03-29',
    currentStep: 2,
    assignedTo: 'akshay'
  },
  {
    id: '19',
    name: 'Rajat Bansal',
    email: 'rajat@example.com',
    phone: '+91 9876543228',
    status: 'blocked',
    itrType: 'ITR-1',
    registrationDate: '2024-01-22',
    lastLogin: '2024-02-11',
    currentStep: 1,
    assignedTo: 'ankush'
  },
  {
    id: '20',
    name: 'Tanya Sehgal',
    email: 'tanya@example.com',
    phone: '+91 9876543229',
    status: 'pending',
    itrType: 'ITR-3',
    registrationDate: '2024-03-30',
    lastLogin: '2024-04-04',
    currentStep: 4,
    assignedTo: 'yash'
  }
];

  const getStepStatus = (step: number) => {
    const stepLabels = {
      1: 'Registered',
      2: 'Profile Complete',
      3: 'Sources Added',
      4: 'Docs Submitted',
      5: 'Payment Done'
    };
    return stepLabels[step as keyof typeof stepLabels] || 'Unknown';
  };

  const handleSearch = (value: string) => {
    setSearchText(value);
  };

  const handleFilter = (value: string) => {
    setFilterStatus(value);
  };

  const handleAssignmentChange = (userId: string, adminId: string) => {
    message.success(`User assigned to ${adminList.find(admin => admin.value === adminId)?.label}`);
  };

  const handleExportToExcel = () => {
    const exportData = users.map(user => ({
      'Name': user.name,
      'Email': user.email,
      'Phone': user.phone,
      'ITR Type': user.itrType,
      'Status': user.status,
      'Current Step': getStepStatus(user.currentStep),
      'Assigned To': adminList.find(admin => admin.value === user.assignedTo)?.label,
      'Registration Date': new Date(user.registrationDate).toLocaleDateString()
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Users');
    XLSX.writeFile(wb, 'user_management.xlsx');
  };

  const handleEditUser = (user: any) => {
    setEditingUser(user);
    form.setFieldsValue(user);
    setIsModalVisible(true);
  };

  const handleModalOk = async () => {
    try {
      const values = await form.validateFields();
      
      // Check if status requires remarks
      const statusRequiringRemarks = ['pending', 'blocked', 'pendingOnClient'];
      if (statusRequiringRemarks.includes(values.status) && !values.remarks) {
        message.error('Please provide remarks for the selected status');
        return;
      }

      if (editingUser) {
        // Send notification if status is changed to 'filed'
        if (values.status === 'filed' && editingUser.status !== 'filed') {
          // Implement notification logic here
          console.log('Sending notifications to user:', {
            email: editingUser.email,
            phone: editingUser.phone,
            message: 'Your ITR has been successfully filed!'
          });
        }
        
        message.success('User updated successfully');
      }
      
      setIsModalVisible(false);
      form.resetFields();
      setEditingUser(null);
    } catch (error) {
      console.error('Validation failed:', error);
    }
  };

  const handleModalCancel = () => {
    setIsModalVisible(false);
    form.resetFields();
    setEditingUser(null);
  };

  const handleDeleteUser = (id: string) => {
    Modal.confirm({
      title: 'Delete User',
      content: 'Are you sure you want to delete this user? This action cannot be undone.',
      okText: 'Yes, Delete',
      okType: 'danger',
      cancelText: 'No, Cancel',
      onOk() {
        message.success('User deleted successfully');
      }
    });
  };

  const columns = [
    {
      title: 'Name',
      dataIndex: 'name',
      key: 'name',
      render: (text: string, record: any) => (
        <Button 
          type="link" 
          onClick={() => navigate(`/admin/users/${record.id}`)}
          className="font-medium p-0"
        >
          {text}
        </Button>
      )
    },
    // {
    //   title: 'Email',
    //   dataIndex: 'email',
    //   key: 'email'
    // },
    {
      title: 'Phone',
      dataIndex: 'phone',
      key: 'phone'
    },
    {
      title: 'ITR Type',
      dataIndex: 'itrType',
      key: 'itrType',
      render: (type: string) => (
        <Tag color="blue">{type}</Tag>
      )
    },
    {
      title: 'Current Journey',
      dataIndex: 'currentStep',
      key: 'currentStep',
      render: (step: number) => (
        <div>
          <Tag color="purple">Step {step} of 5</Tag>
          <div className="text-xs text-gray-500 mt-1">{getStepStatus(step)}</div>
        </div>
      ),
      filters: [
        { text: 'Registration Complete', value: 1 },
        { text: 'Profile Complete', value: 2 },
        { text: 'Income Sources Added', value: 3 },
        { text: 'Document Uploaded', value: 4 },
        { text: 'Payment Done', value: 5 },
      ],
      onFilter: (value: number, record: any) => record.currentStep === value
    },
    {
      title: 'Assigned To',
      dataIndex: 'assignedTo',
      key: 'assignedTo',
      render: (assignedTo: string, record: any) => (
        <Select
          value={assignedTo}
          onChange={(value) => handleAssignmentChange(record.id, value)}
          style={{ width: 150 }}
          options={adminList}
        />
      ),
      filters: adminList.map(admin => ({
        text: admin.label,
        value: admin.value
      })),
      onFilter: (value: string, record: any) => record.assignedTo === value
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status: string, record: any) => {
        const colors: { [key: string]: string } = {
          filed: 'success',
          inProgress: 'processing',
          pending: 'warning',
          blocked: 'error',
          pendingOnClient: 'orange',
          paymentPending: 'yellow',
        };

    const labelMap: { [key: string]: string } = {
      filed: 'Filed',
      inProgress: 'In Progress',
      pending: 'Pending',
      blocked: 'Blocked',
      pendingOnClient: 'Pending on Client',
      paymentPending: 'Payment Pending',
    };
        
        return (
          <div>
            <Tag color={colors[status]}>
              {labelMap[status] || status}
            </Tag>
            {record.remarks && (
              <div className="text-xs text-gray-500 mt-1">
                {record.remarks}
              </div>
            )}
          </div>
        );
      },
      filters: [
        { text: 'Filed', value: 'filed' },
        { text: 'In Progress', value: 'inProgress' },
        { text: 'Pending', value: 'pending' },
        { text: 'Blocked', value: 'blocked' },
        { text: 'Pending on Client', value: 'pendingOnClient' },
        { text: 'Payment Pending', value: 'paymentPending' }
      ],
      onFilter: (value: string, record: any) => record.status === value
    },
    {
      title: 'Action',
      key: 'action',
      render: (_: any, record: any) => (
        <Space>
          <Button 
            type="text" 
            icon={<Edit2 size={16} />}
            onClick={() => handleEditUser(record)}
          />
          <Button 
            type="text" 
            danger 
            icon={<Trash2 size={16} />}
            onClick={() => handleDeleteUser(record.id)}
          />
          {/* <Button 
            type="text"
            icon={<FileText size={16} />}
            onClick={() => navigate(`/admin/users/${record.id}`)}
          /> */}
        </Space>
      )
    }
  ];

  return (
    <AdminLayout darkMode={darkMode} toggleTheme={toggleTheme} title="User Management">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4 md:p-8"
      >
        <div className="max-w-6xl mx-auto lg:ml-64 px-4">
          <Card className="shadow-md">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
              <div className="flex flex-col md:flex-row gap-4 flex-grow">
                <Input.Search
                  placeholder="Search by name, email, or phone..."
                  onSearch={handleSearch}
                  className="w-full md:w-64"
                  allowClear
                />
              </div>
              <Space>
                <Button
                  type="primary"
                  icon={<Download size={18} />}
                  onClick={handleExportToExcel}
                >
                  Export to Excel
                </Button>
              </Space>
            </div>

            <Table
              columns={columns}
              dataSource={users}
              rowKey="id"
              scroll={{ x: true }}
              pagination={{
                total: users.length,
                pageSize: 10,
                showSizeChanger: true,
                showQuickJumper: true
              }}
            />
          </Card>
        </div>
      </motion.div>

      <Modal
        title={editingUser ? "Edit User" : "Add New User"}
        open={isModalVisible}
        onOk={handleModalOk}
        onCancel={handleModalCancel}
        width={600}
      >
        <Form
          form={form}
          layout="vertical"
          className="mt-4"
        >
          <Form.Item
            name="name"
            label="Full Name"
            rules={[{ required: true, message: 'Please enter user name' }]}
          >
            <Input prefix={<User className="text-gray-400" size={18} />} />
          </Form.Item>
          <Form.Item
            name="email"
            label="Email"
            rules={[
              { required: true, message: 'Please enter email' },
              { type: 'email', message: 'Please enter a valid email' }
            ]}
          >
            <Input prefix={<Mail className="text-gray-400" size={18} />} />
          </Form.Item>
          <Form.Item
            name="phone"
            label="Phone"
            rules={[{ required: true, message: 'Please enter phone number' }]}
          >
            <Input prefix={<Phone className="text-gray-400" size={18} />} />
          </Form.Item>
          <Form.Item
            name="itrType"
            label="ITR Type"
            rules={[{ required: true, message: 'Please select ITR type' }]}
          >
            <Select
              options={[
                { value: 'ITR-1', label: 'ITR-1' },
                { value: 'ITR-2', label: 'ITR-2' },
                { value: 'ITR-3', label: 'ITR-3' },
                { value: 'ITR-4', label: 'ITR-4' }
              ]}
            />
          </Form.Item>
          <Form.Item
            name="status"
            label="Status"
            rules={[{ required: true, message: 'Please select status' }]}
          >
            <Select
              options={[
                { value: 'filed', label: 'Filed' },
                { value: 'inProgress', label: 'In Progress' },
                { value: 'pending', label: 'Pending' },
                { value: 'blocked', label: 'Blocked' },
                { value: 'pendingOnClient', label: 'Pending on Client' },
                { value: 'paymentPending', label: 'Payment Pending' }
              ]}
            />

            
          </Form.Item>

          <Form.Item
            noStyle
            shouldUpdate={(prevValues, currentValues) => prevValues.status !== currentValues.status}
          >
            {({ getFieldValue }) => {
              const status = getFieldValue('status');
              const needsRemarks = ['pending', 'blocked', 'pendingOnClient'].includes(status);
              
              return needsRemarks ? (
                <Form.Item
                  name="remarks"
                  label="Remarks"
                  rules={[{ required: true, message: 'Please provide remarks for the selected status' }]}
                >
                  <Input.TextArea 
                    placeholder="Enter reason for the selected status"
                    rows={3}
                  />
                </Form.Item>
              ) : null;
            }}
          </Form.Item>

          <Form.Item
            name="assignedTo"
            label="Assigned To"
            rules={[{ required: true, message: 'Please select an admin' }]}
          >
            <Select options={adminList} />
          </Form.Item>
        </Form>
      </Modal>
    </AdminLayout>
  );
};

export default UserManagement;