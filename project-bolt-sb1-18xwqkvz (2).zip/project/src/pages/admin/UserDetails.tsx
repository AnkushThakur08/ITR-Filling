import React from 'react';
import { Card, Descriptions, Button, Tag, List, Space, message } from 'antd';
import { motion } from 'framer-motion';
import { Download, FileText, Mail, Phone, Calendar, MapPin, CreditCard } from 'lucide-react';
import { useParams, useNavigate } from 'react-router-dom';
import AdminLayout from '../../components/AdminLayout';

interface UserDetailsProps {
  darkMode: boolean;
  toggleTheme: () => void;
}

const UserDetails: React.FC<UserDetailsProps> = ({ darkMode, toggleTheme }) => {
  const { id } = useParams();
  const navigate = useNavigate();

  // Mock user data - replace with API call
  const user = {
    id: '1',
    name: 'John Doe',
    email: 'john@example.com',
    phone: '+91 9876543210',
    pan: 'ABCDE1234F',
    address: '123 Tax Street, Financial District',
    pincode: '400001',
    dateOfBirth: '1990-05-15',
    itrType: 'ITR-2',
    status: 'active',
    currentStep: 3,
    registrationDate: '2024-03-15',
    lastLogin: '2024-03-20',
    documents: [
      {
        id: 1,
        name: 'Form 16.pdf',
        type: 'Form 16',
        uploadDate: '2024-03-16',
        size: '2.5 MB'
      },
      {
        id: 2,
        name: 'Bank Statement.pdf',
        type: 'Bank Statement',
        uploadDate: '2024-03-16',
        size: '1.8 MB'
      },
      {
        id: 3,
        name: 'Investment Proofs.pdf',
        type: 'Investment Documents',
        uploadDate: '2024-03-16',
        size: '3.2 MB'
      }
    ]
  };

  const handleDownloadAll = () => {
    message.success('Downloading all documents...');
  };

  const handleDownloadDocument = (document: any) => {
    message.success(`Downloading ${document.name}...`);
  };

  const getStepStatus = (step: number) => {
    const stepLabels = {
      1: 'Registration Completed',
      2: 'Income Source Selected',
      3: 'Documents Uploaded',
      4: 'Payment Completed'
    };
    return stepLabels[step as keyof typeof stepLabels] || 'Unknown';
  };

  return (
    <AdminLayout darkMode={darkMode} toggleTheme={toggleTheme} title="User Details">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4 md:p-8"
      >
        <div className="max-w-6xl mx-auto lg:ml-64 px-4">
          <div className="mb-6 flex justify-between items-center">
            <Button onClick={() => navigate('/admin/users')}>Back to Users</Button>
            <Button type="primary" onClick={handleDownloadAll} icon={<Download size={18} />}>
              Download All Documents
            </Button>
          </div>

          <div className="grid grid-cols-1 gap-6">
            <Card title="Personal Information" className="shadow-md">
              <Descriptions column={{ xs: 1, sm: 2, md: 3 }} bordered>
                <Descriptions.Item label="Full Name">{user.name}</Descriptions.Item>
                <Descriptions.Item label="Email">{user.email}</Descriptions.Item>
                <Descriptions.Item label="Phone">{user.phone}</Descriptions.Item>
                <Descriptions.Item label="PAN">{user.pan}</Descriptions.Item>
                <Descriptions.Item label="Address">{user.address}</Descriptions.Item>
                <Descriptions.Item label="Pincode">{user.pincode}</Descriptions.Item>
                <Descriptions.Item label="Date of Birth">
                  {new Date(user.dateOfBirth).toLocaleDateString()}
                </Descriptions.Item>
                <Descriptions.Item label="ITR Type">
                  <Tag color="blue">{user.itrType}</Tag>
                </Descriptions.Item>
                <Descriptions.Item label="Status">
                  <Tag color={user.status === 'active' ? 'success' : 'warning'}>
                    {user.status.charAt(0).toUpperCase() + user.status.slice(1)}
                  </Tag>
                </Descriptions.Item>
              </Descriptions>
            </Card>

            <Card title="User Journey" className="shadow-md">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-medium">Current Step</h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      {getStepStatus(user.currentStep)}
                    </p>
                  </div>
                  <Tag color="blue">Step {user.currentStep} of 4</Tag>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className="bg-blue-600 h-2.5 rounded-full" 
                    style={{ width: `${(user.currentStep / 4) * 100}%` }}
                  ></div>
                </div>
              </div>
            </Card>

            <Card title="Uploaded Documents" className="shadow-md">
              <List
                itemLayout="horizontal"
                dataSource={user.documents}
                renderItem={document => (
                  <List.Item
                    actions={[
                      <Button 
                        key="download"
                        type="text"
                        icon={<Download size={16} />}
                        onClick={() => handleDownloadDocument(document)}
                      >
                        Download
                      </Button>
                    ]}
                  >
                    <List.Item.Meta
                      avatar={<FileText className="h-6 w-6 text-blue-500" />}
                      title={document.name}
                      description={
                        <Space>
                          <span>{document.type}</span>
                          <span>•</span>
                          <span>{document.size}</span>
                          <span>•</span>
                          <span>Uploaded on {new Date(document.uploadDate).toLocaleDateString()}</span>
                        </Space>
                      }
                    />
                  </List.Item>
                )}
              />
            </Card>
          </div>
        </div>
      </motion.div>
    </AdminLayout>
  );
};

export default UserDetails;