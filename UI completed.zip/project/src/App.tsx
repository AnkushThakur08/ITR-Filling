import React, { useState } from 'react';
import { ConfigProvider, theme } from 'antd';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from 'react-query';
import Navbar from './components/Navbar';
import Header from './components/Header';
import Hero from './components/Hero';
import Features from './components/Features';
import HowItWorks from './components/HowItWorks';
import WhyChooseUs from './components/WhyChooseUs';
import Testimonials from './components/Testimonials';
import FAQ from './components/FAQ';
import Footer from './components/Footer';
import Login from './pages/auth/Login';
import Signup from './pages/auth/Signup';
import TermsAndConditions from './pages/auth/TermsAndConditions';
import AdminLogin from './pages/admin/AdminLogin';
import AdminDashboard from './pages/admin/AdminDashboard';
import UserManagement from './pages/admin/UserManagement';
import UserDetails from './pages/admin/UserDetails';
import PaymentManagement from './pages/admin/PaymentManagement';
import AdminManagement from './pages/admin/AdminManagement';
import OnboardingStepper from './pages/onboarding/OnboardingStepper';
import Dashboard from './pages/dashboard/Dashboard';
import PersonalDetails from './pages/dashboard/PersonalDetails';
import DocumentCenter from './pages/dashboard/DocumentCenter';
import Payments from './pages/dashboard/Payments';
import Settings from './pages/dashboard/Settings';
import TaxCalculator from './pages/dashboard/TaxCalculator';
import Support from './pages/dashboard/Support';
import './index.css';

const queryClient = new QueryClient();

const App: React.FC = () => {
  const [darkMode, setDarkMode] = useState<boolean>(false);
  
  const toggleTheme = () => {
    setDarkMode(!darkMode);
  };

  // Check if user has accepted terms
  const hasAcceptedTerms = () => {
    return localStorage.getItem('termsAccepted') === 'true';
  };
  
  return (
    <QueryClientProvider client={queryClient}>
      <ConfigProvider
        theme={{
          algorithm: darkMode ? theme.darkAlgorithm : theme.defaultAlgorithm,
          token: {
            colorPrimary: '#0EA5E9',
            borderRadius: 8,
          },
        }}
      >
        <Router>
          <div className={darkMode ? 'dark' : 'light'}>
            <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 transition-colors duration-300">
              <Routes>
                <Route 
                  path="/" 
                  element={
                    <>
                      <Navbar darkMode={darkMode} toggleTheme={toggleTheme} />
                      <Header />
                      <main>
                        <Hero />
                        <Features />
                        <HowItWorks />
                        <WhyChooseUs />
                        <Testimonials />
                        <FAQ />
                      </main>
                      <Footer />
                    </>
                  } 
                />
                <Route path="/login" element={<Login />} />
                <Route path="/signup" element={<Signup />} />
                <Route path="/terms" element={<TermsAndConditions />} />
                <Route path="/admin/login" element={<AdminLogin />} />
                <Route path="/admin/dashboard" element={<AdminDashboard darkMode={darkMode} toggleTheme={toggleTheme} />} />
                <Route path="/admin/users" element={<UserManagement darkMode={darkMode} toggleTheme={toggleTheme} />} />
                <Route path="/admin/users/:id" element={<UserDetails darkMode={darkMode} toggleTheme={toggleTheme} />} />
                <Route path="/admin/payments" element={<PaymentManagement darkMode={darkMode} toggleTheme={toggleTheme} />} />
                <Route path="/admin/management" element={<AdminManagement darkMode={darkMode} toggleTheme={toggleTheme} />} />
                
                {/* Protected Routes - Redirect to terms if not accepted */}
                <Route 
                  path="/onboarding" 
                  element={
                    hasAcceptedTerms() ? (
                      <OnboardingStepper />
                    ) : (
                      <Navigate to="/terms" replace />
                    )
                  } 
                />
                <Route 
                  path="/dashboard" 
                  element={
                    hasAcceptedTerms() ? (
                      <Dashboard darkMode={darkMode} toggleTheme={toggleTheme} />
                    ) : (
                      <Navigate to="/terms" replace />
                    )
                  } 
                />
                <Route 
                  path="/dashboard/personal" 
                  element={
                    hasAcceptedTerms() ? (
                      <PersonalDetails darkMode={darkMode} toggleTheme={toggleTheme} />
                    ) : (
                      <Navigate to="/terms" replace />
                    )
                  } 
                />
                <Route 
                  path="/dashboard/documents" 
                  element={
                    hasAcceptedTerms() ? (
                      <DocumentCenter darkMode={darkMode} toggleTheme={toggleTheme} />
                    ) : (
                      <Navigate to="/terms" replace />
                    )
                  } 
                />
                <Route 
                  path="/dashboard/payments" 
                  element={
                    hasAcceptedTerms() ? (
                      <Payments darkMode={darkMode} toggleTheme={toggleTheme} />
                    ) : (
                      <Navigate to="/terms" replace />
                    )
                  } 
                />
                <Route 
                  path="/dashboard/calculator" 
                  element={
                    hasAcceptedTerms() ? (
                      <TaxCalculator darkMode={darkMode} toggleTheme={toggleTheme} />
                    ) : (
                      <Navigate to="/terms" replace />
                    )
                  } 
                />
                <Route 
                  path="/dashboard/settings" 
                  element={
                    hasAcceptedTerms() ? (
                      <Settings darkMode={darkMode} toggleTheme={toggleTheme} />
                    ) : (
                      <Navigate to="/terms" replace />
                    )
                  } 
                />
                <Route 
                  path="/dashboard/support" 
                  element={
                    hasAcceptedTerms() ? (
                      <Support darkMode={darkMode} toggleTheme={toggleTheme} />
                    ) : (
                      <Navigate to="/terms" replace />
                    )
                  } 
                />
              </Routes>
            </div>
          </div>
        </Router>
      </ConfigProvider>
    </QueryClientProvider>
  );
};

export default App;