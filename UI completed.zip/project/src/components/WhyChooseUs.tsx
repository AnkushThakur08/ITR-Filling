import React from 'react';
import { motion } from 'framer-motion';
import { WhyChooseUsItemProps } from '../types';
import { Shield, Clock, Award, HeartHandshake } from 'lucide-react';

const WhyChooseUs: React.FC = () => {
  const reasons: WhyChooseUsItemProps[] = [
    {
      id: 1,
      title: 'Security First Approach',
      description: 'We implement multiple layers of security to keep your financial data safe. Your information is encrypted and protected with the latest technology.',
      icon: <Shield className="h-12 w-12 text-blue-600" />
    },
    {
      id: 2,
      title: 'Fast & Efficient Processing',
      description: 'Our streamlined system ensures your tax returns are processed quickly, minimizing errors and helping you get refunds faster.',
      icon: <Clock className="h-12 w-12 text-blue-600" />
    },
    {
      id: 3,
      title: 'Trusted by Millions',
      description: 'Join millions of satisfied customers who trust us with their annual tax filing needs. Our track record speaks for itself.',
      icon: <Award className="h-12 w-12 text-blue-600" />
    },
    {
      id: 4,
      title: 'Customer-Centric Approach',
      description: 'We put your needs first, with intuitive interfaces, helpful guidance, and responsive customer support available when you need it.',
      icon: <HeartHandshake className="h-12 w-12 text-blue-600" />
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  return (
    <section className="py-16 bg-white dark:bg-gray-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <motion.h2 
            initial={{ opacity: 0, y: -20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-3xl font-bold mb-4"
          >
            Why Choose TaxEase
          </motion.h2>
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
            className="text-lg text-gray-600 dark:text-gray-400 max-w-3xl mx-auto"
          >
            We're committed to making tax filing simple, secure, and stress-free. Here's why thousands trust us every day.
          </motion.p>
        </div>
        
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid md:grid-cols-2 gap-8"
        >
          {reasons.map((reason) => (
            <motion.div
              key={reason.id}
              variants={itemVariants}
              className="bg-blue-50 dark:bg-gray-700 p-8 rounded-lg border-l-4 border-blue-500"
            >
              <div className="flex items-start">
                <div className="mr-4">{reason.icon}</div>
                <div>
                  <h3 className="text-xl font-semibold mb-3">{reason.title}</h3>
                  <p className="text-gray-600 dark:text-gray-300">{reason.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
        
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="mt-16 bg-gradient-to-r from-blue-600 to-blue-800 rounded-lg p-8 md:p-12 text-center text-white"
        >
          <h3 className="text-2xl font-bold mb-4">Ready to Experience Hassle-Free Tax Filing?</h3>
          <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
            Join thousands of satisfied customers who file their taxes with confidence and ease every year.
          </p>
          <button className="bg-white text-blue-700 px-8 py-3 rounded-md font-medium hover:bg-blue-50 transition-colors">
            Get Started Today
          </button>
        </motion.div>
      </div>
    </section>
  );
};

export default WhyChooseUs;