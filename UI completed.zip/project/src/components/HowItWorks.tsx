import React from 'react';
import { motion } from 'framer-motion';
import { LogIn, User, DollarSign, FileText, CreditCard, CheckCircle2, IndianRupee } from 'lucide-react';

const HowItWorks: React.FC = () => {
  const steps = [
    {
      icon: <LogIn className="h-12 w-12 text-blue-500" />,
      title: 'Login/SignUp',
      description: 'Create your account in minutes',
      bgColor: 'bg-blue-50 dark:bg-blue-900/30'
    },
    {
      icon: <User className="h-12 w-12 text-purple-500" />,
      title: 'Personal Details',
      description: 'Fill in your basic information',
      bgColor: 'bg-purple-50 dark:bg-purple-900/30'
    },
    {
      icon: <DollarSign className="h-12 w-12 text-green-500" />,
      title: 'Income Sources',
      description: 'Select your sources of income',
      bgColor: 'bg-green-50 dark:bg-green-900/30'
    },
    {
      icon: <FileText className="h-12 w-12 text-orange-500" />,
      title: 'Upload Documents',
      description: 'Share your financial documents',
      bgColor: 'bg-orange-50 dark:bg-orange-900/30'
    },
    {
      icon: <CreditCard className="h-12 w-12 text-red-500" />,
      title: 'Complete Payment',
      description: 'Choose your preferred payment method',
      bgColor: 'bg-red-50 dark:bg-red-900/30'
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  return (
    <section className="py-16 bg-gradient-to-b from-white to-gray-50 dark:from-gray-800 dark:to-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="inline-block mb-4 px-6 py-2 bg-blue-100 dark:bg-blue-900/50 rounded-full"
          >
            <span className="text-blue-600 dark:text-blue-400 font-semibold">Simple Process</span>
          </motion.div>
          <motion.h2 
            initial={{ opacity: 0, y: -20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-4xl font-bold mb-4"
          >
            How It Works
          </motion.h2>
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
            className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto"
          >
            Complete Your Income Tax Return in 5 Easy Steps
          </motion.p>
        </div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="relative"
        >
          {/* Connection Line */}
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 via-purple-500 to-red-500 transform -translate-y-1/2 z-0" />

          {/* Steps */}
          <div className="grid md:grid-cols-3 lg:grid-cols-5 gap-8 relative z-10">
            {steps.map((step, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                className="relative group"
              >
                <div className={`${step.bgColor} rounded-xl p-8 text-center shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1`}>
                  <div className="flex justify-center mb-6">
                    <div className="p-4 rounded-full bg-white dark:bg-gray-800 shadow-md">
                      {step.icon}
                    </div>
                  </div>
                  <span className="inline-block px-4 py-1 bg-white dark:bg-gray-800 rounded-full text-sm font-semibold mb-4">
                    Step {index + 1}
                  </span>
                  <h3 className="text-xl font-semibold mb-3">{step.title}</h3>
                  <p className="text-gray-600 dark:text-gray-400">{step.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="mt-20 bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-12 text-center text-white relative overflow-hidden"
        >
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0" style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M54.627 0l.83.828-1.415 1.415L51.8 0h2.827zM5.373 0l-.83.828L5.96 2.243 8.2 0H5.374zM48.97 0l3.657 3.657-1.414 1.414L46.143 0h2.828zM11.03 0L7.372 3.657 8.787 5.07 13.857 0H11.03zm32.284 0L49.8 6.485 48.384 7.9l-7.9-7.9h2.83zM16.686 0L10.2 6.485 11.616 7.9l7.9-7.9h-2.83zM22.343 0L13.8 8.485 15.214 9.9l9.9-9.9h-2.77zM32 0l-9.9 9.9 1.415 1.415L34.828 0H32zm-3.657 0l-9.9 9.9 1.415 1.415L31.172 0h-2.829zM8.485 0L0 8.485l1.415 1.415L11.314 0H8.485zM54.627 10l.83.828-1.415 1.415L51.8 10h2.827zM5.373 10l-.83.828 1.415 1.415L8.2 10H5.374zM48.97 10l3.657 3.657-1.414 1.414L46.143 10h2.828zM11.03 10l-3.657 3.657 1.414 1.414L13.857 10H11.03zm32.284 0L49.8 16.485l-1.415 1.415-7.9-7.9h2.83zM16.686 10l-6.485 6.485 1.415 1.415 7.9-7.9h-2.83zM22.343 10L13.8 18.485l1.414 1.415 9.9-9.9h-2.77zM32 10l-9.9 9.9 1.415 1.415L34.828 10H32zm-3.657 0l-9.9 9.9 1.415 1.415L31.172 10h-2.829zM8.485 10L0 18.485l1.415 1.415L11.314 10H8.485z' fill='%23FFFFFF' fill-opacity='0.1' fill-rule='evenodd'/%3E%3C/svg%3E")`,
              backgroundSize: '30px 30px'
            }} />
          </div>

          <div className="relative z-10">
            <div className="flex items-center justify-center mb-6">
              <CheckCircle2 className="h-16 w-16 mr-4" />
              <h3 className="text-3xl font-bold">Expert Tax Filing</h3>
            </div>
            <p className="text-2xl text-blue-100 mb-8 max-w-3xl mx-auto leading-relaxed">
              Every ITR is meticulously prepared by our qualified tax experts, ensuring maximum benefits and complete accuracy.
            </p>
            <div className="flex items-center justify-center space-x-2 text-xl font-semibold mb-8">
              <span>Starting from</span>
              <div className="flex items-center">
                <IndianRupee className="h-5 w-5" />
                <span>299</span>
              </div>
              <span>only</span>
            </div>
            <button className="bg-white text-blue-600 px-10 py-4 rounded-lg font-semibold text-lg hover:bg-blue-50 transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-transform duration-300">
              Start Filing Now
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default HowItWorks;