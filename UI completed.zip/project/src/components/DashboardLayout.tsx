import React, { useState } from 'react';
import { Layout, Menu, Button, Drawer } from 'antd';
import { Link, useLocation } from 'react-router-dom';
import { Home, FileText, CreditCard, Settings, LogOut, Sun, Moon, Menu as MenuIcon, Calculator, HeadphonesIcon } from 'lucide-react';
import NotificationBell from './NotificationBell';

const { Header, Sider, Content } = Layout;

interface DashboardLayoutProps {
  children: React.ReactNode;
  darkMode: boolean;
  toggleTheme: () => void;
  title: string;
}

const DashboardLayout: React.FC<DashboardLayoutProps> = ({ children, darkMode, toggleTheme, title }) => {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const menuItems = [
    {
      key: 'dashboard',
      icon: <Home size={18} />,
      label: 'Dashboard',
      path: '/dashboard'
    },
    {
      key: 'personal',
      icon: <FileText size={18} />,
      label: 'Personal Details',
      path: '/dashboard/personal'
    },
    {
      key: 'documents',
      icon: <FileText size={18} />,
      label: 'Document Center',
      path: '/dashboard/documents'
    },
    {
      key: 'payments',
      icon: <CreditCard size={18} />,
      label: 'Payments',
      path: '/dashboard/payments'
    },
    {
      key: 'calculator',
      icon: <Calculator size={18} />,
      label: 'Tax Calculator',
      path: '/dashboard/calculator'
    },
    {
      key: 'support',
      icon: <HeadphonesIcon size={18} />,
      label: 'Support',
      path: '/dashboard/support'
    },
    {
      key: 'settings',
      icon: <Settings size={18} />,
      label: 'Settings',
      path: '/dashboard/settings'
    }
  ];

  const SidebarContent = ({ isMobile = false }) => (
    <div className="flex flex-col h-full">
      <div className="h-16 flex items-center justify-center border-b">
        <Link to="/" className="text-xl font-bold text-blue-600">TaxEase</Link>
      </div>
      <Menu
        mode="inline"
        selectedKeys={[location.pathname.split('/')[2] || 'dashboard']}
        className="flex-1"
        items={menuItems.map(item => ({
          key: item.key,
          icon: item.icon,
          label: <Link to={item.path}>{item.label}</Link>
        }))}
      />
      {!isMobile && (
        <div className="p-4 border-t">
          <Button
            icon={<LogOut size={18} />}
            type="text"
            danger
            className="w-full text-left"
          >
            Logout
          </Button>
        </div>
      )}
    </div>
  );

  return (
    <Layout className="min-h-screen">
      {/* Desktop Sidebar */}
      <Sider
        width={280}
        className="bg-white dark:bg-gray-800 shadow-lg hidden md:block"
        style={{ height: '100vh', position: 'fixed', left: 0 }}
      >
        <SidebarContent />
      </Sider>

      {/* Mobile Drawer */}
      <Drawer
        placement="left"
        open={mobileMenuOpen}
        onClose={() => setMobileMenuOpen(false)}
        width={280}
        bodyStyle={{ padding: 0 }}
        title={null}
      >
        <SidebarContent isMobile={true} />
      </Drawer>

      <Layout style={{ marginLeft: { xs: 0, md: 280 } }}>
        <Header className="bg-white dark:bg-gray-800 shadow-sm px-4 md:px-8 flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center">
            <Button
              type="text"
              icon={<MenuIcon size={24} />}
              onClick={() => setMobileMenuOpen(true)}
              className="mr-4 md:hidden"
            />
            <h2 className="text-xl font-semibold">{title}</h2>
          </div>
          <div className="flex items-center space-x-4">
            <NotificationBell />
            <Button
              type="text"
              icon={darkMode ? <Sun size={20} /> : <Moon size={20} />}
              onClick={toggleTheme}
              className="flex items-center justify-center"
              aria-label="Toggle theme"
            />
          </div>
        </Header>
        
        <Content className="min-h-screen bg-gray-50 dark:bg-gray-900">
          {children}
        </Content>
      </Layout>
    </Layout>
  );
};

export default DashboardLayout;