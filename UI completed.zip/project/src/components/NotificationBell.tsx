import React from 'react';
import { Badge, Dropdown, List, Button, Empty, Tag } from 'antd';
import { Bell, Check, Trash2, Clock } from 'lucide-react';
import useNotificationStore from '../store/notificationStore';

const NotificationBell: React.FC = () => {
  const { 
    notifications, 
    unreadCount, 
    markAsRead, 
    markAllAsRead, 
    clearNotification, 
    clearAllNotifications 
  } = useNotificationStore();

  const getNotificationColor = (type: string) => {
    const colors = {
      info: 'blue',
      success: 'green',
      warning: 'orange',
      error: 'red'
    };
    return colors[type as keyof typeof colors] || 'blue';
  };

  const notificationList = (
    <div className="w-96 max-h-[80vh] overflow-hidden bg-white dark:bg-gray-800 rounded-lg shadow-lg flex flex-col">
      <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center flex-shrink-0">
        <div>
          <h3 className="text-lg font-semibold">Notifications</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            {unreadCount} unread notifications
          </p>
        </div>
        <div className="space-x-2">
          {unreadCount > 0 && (
            <Button 
              type="text" 
              size="small"
              icon={<Check size={14} />}
              onClick={markAllAsRead}
            >
              Mark all read
            </Button>
          )}
          {notifications.length > 0 && (
            <Button 
              type="text" 
              size="small"
              icon={<Trash2 size={14} />}
              onClick={clearAllNotifications}
              danger
            >
              Clear all
            </Button>
          )}
        </div>
      </div>

      <div className="overflow-y-auto flex-grow">
        {notifications.length > 0 ? (
          <List
            dataSource={notifications}
            renderItem={(notification) => (
              <List.Item
                className={`cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 border-b border-gray-100 dark:border-gray-700 ${
                  !notification.read ? 'bg-blue-50 dark:bg-blue-900/20' : ''
                }`}
                onClick={() => markAsRead(notification.id)}
              >
                <div className="p-4 w-full">
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex items-center">
                      <Tag color={getNotificationColor(notification.type)}>
                        {notification.type.charAt(0).toUpperCase() + notification.type.slice(1)}
                      </Tag>
                      <span className="font-medium ml-2">{notification.title}</span>
                    </div>
                    <Button
                      type="text"
                      size="small"
                      icon={<Trash2 size={14} />}
                      onClick={(e) => {
                        e.stopPropagation();
                        clearNotification(notification.id);
                      }}
                      className="opacity-0 group-hover:opacity-100 transition-opacity"
                    />
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                    {notification.message}
                  </p>
                  <div className="flex items-center text-xs text-gray-500 dark:text-gray-400">
                    <Clock size={12} className="mr-1" />
                    {new Date(notification.timestamp).toLocaleString()}
                  </div>
                </div>
              </List.Item>
            )}
          />
        ) : (
          <Empty
            image={Empty.PRESENTED_IMAGE_SIMPLE}
            description="No notifications"
            className="py-8"
          />
        )}
      </div>
    </div>
  );

  return (
    <Dropdown 
      overlay={notificationList} 
      trigger={['click']}
      placement="bottomRight"
      overlayStyle={{ minWidth: '384px' }}
    >
      <Badge count={unreadCount} className="cursor-pointer">
        <Bell className="h-6 w-6 text-gray-600 dark:text-gray-300" />
      </Badge>
    </Dropdown>
  );
};

export default NotificationBell;