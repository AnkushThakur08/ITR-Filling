import React from 'react';
import { Collapse } from 'antd';
import { motion } from 'framer-motion';
import { FAQItemProps } from '../types';

const { Panel } = Collapse;

const FAQ: React.FC = () => {
  const faqs: FAQItemProps[] = [
    {
      id: 1,
      question: 'What documents do I need to file my ITR?',
      answer: 'You\'ll need your Form 16 from your employer, bank statements for interest income, investment statements (mutual funds, stocks), home loan statements if applicable, and details of any other income sources. Our platform will guide you through the specific documents needed based on your tax situation.'
    },
    {
      id: 2,
      question: 'How secure is your platform for sharing financial information?',
      answer: 'We use bank-level encryption (256-bit SSL) to protect all data transfers. Your information is stored with multiple layers of security and access controls. We\'re committed to industry best practices for data protection and comply with all relevant regulations regarding financial data.'
    },
    {
      id: 3,
      question: 'Which ITR form should I use?',
      answer: 'The correct ITR form depends on your sources of income. Our platform automatically determines the appropriate form based on the income details you provide, ensuring compliance while simplifying the process for you.'
    },
    {
      id: 4,
      question: 'How long does it take to file an ITR using your service?',
      answer: 'Most users complete their filing in 15-30 minutes if they have all documents ready. The exact time depends on the complexity of your tax situation, but our streamlined process is designed to be efficient while ensuring accuracy.'
    },
    {
      id: 5,
      question: 'Will I get help if I\'m audited?',
      answer: 'Yes, our premium plans include audit assistance. If you\'re selected for an audit, our tax experts will help you understand what\'s needed and provide guidance throughout the process to ensure you\'re prepared.'
    },
    {
      id: 6,
      question: 'Can I file ITR after the deadline?',
      answer: 'Yes, you can file a belated return within a specified period after the deadline, but it may involve penalties. Our platform supports belated filings and will automatically calculate any applicable late fees or interest.'
    }
  ];

  return (
    <section id="faq" className="py-16 bg-white dark:bg-gray-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <motion.h2 
            initial={{ opacity: 0, y: -20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-3xl font-bold mb-4"
          >
            Frequently Asked Questions
          </motion.h2>
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
            className="text-lg text-gray-600 dark:text-gray-400 max-w-3xl mx-auto"
          >
            Find answers to common questions about tax filing and our platform.
          </motion.p>
        </div>
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto"
        >
          <Collapse 
            defaultActiveKey={['1']}
            expandIconPosition="end"
            className="bg-transparent"
          >
            {faqs.map((faq) => (
              <Panel 
                key={faq.id} 
                header={<span className="text-lg font-medium">{faq.question}</span>}
                className="mb-4 rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700"
              >
                <p className="text-gray-600 dark:text-gray-300">{faq.answer}</p>
              </Panel>
            ))}
          </Collapse>
          
          <div className="mt-12 text-center">
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              Didn't find what you're looking for?
            </p>
            <button className="bg-blue-600 text-white px-6 py-3 rounded-md font-medium hover:bg-blue-700 transition-colors">
              Contact Support
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default FAQ;