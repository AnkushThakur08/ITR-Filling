import React from 'react';
import { motion } from 'framer-motion';
import { FeatureItemProps } from '../types';
import { FileText, Shield, CreditCard, BarChart4, Clock, MessageSquareText } from 'lucide-react';

const Features: React.FC = () => {
  const features: FeatureItemProps[] = [
    {
      id: 1,
      title: 'Smart ITR Filing',
      description: 'Our intelligent system guides you through the filing process, suggesting the best tax-saving options based on your income and investments.',
      icon: <FileText className="h-10 w-10 text-blue-500" />
    },
    {
      id: 2,
      title: 'Bank-Level Security',
      description: 'Your financial data is encrypted with bank-level security protocols. We maintain strict privacy standards to protect your sensitive information.',
      icon: <Shield className="h-10 w-10 text-blue-500" />
    },
    {
      id: 3,
      title: 'Seamless Payments',
      description: 'Pay taxes or receive refunds with our integrated payment system. Multiple payment options available for your convenience.',
      icon: <CreditCard className="h-10 w-10 text-blue-500" />
    },
    {
      id: 4,
      title: 'Detailed Analytics',
      description: 'Get insights into your tax history with comprehensive analytics. Visualize your tax trends and plan better for future savings.',
      icon: <BarChart4 className="h-10 w-10 text-blue-500" />
    },
    {
      id: 5,
      title: 'Quick Processing',
      description: 'Our efficient system ensures your tax returns are processed quickly, helping you get refunds faster than traditional methods.',
      icon: <Clock className="h-10 w-10 text-blue-500" />
    },
    {
      id: 6,
      title: 'Expert Support',
      description: 'Have questions? Our tax experts are available to assist you at every step of the filing process via chat or email.',
      icon: <MessageSquareText className="h-10 w-10 text-blue-500" />
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.4 }
    }
  };

  return (
    <section id="features" className="py-16 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <motion.h2 
            initial={{ opacity: 0, y: -20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-3xl font-bold mb-4"
          >
            Features Designed for Hassle-Free Tax Filing
          </motion.h2>
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
            className="text-lg text-gray-600 dark:text-gray-400 max-w-3xl mx-auto"
          >
            Everything you need to file your taxes efficiently and maximize your returns, all in one platform.
          </motion.p>
        </div>
        
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {features.map((feature) => (
            <motion.div
              key={feature.id}
              variants={itemVariants}
              className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300"
            >
              <div className="mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
              <p className="text-gray-600 dark:text-gray-300">{feature.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Features;