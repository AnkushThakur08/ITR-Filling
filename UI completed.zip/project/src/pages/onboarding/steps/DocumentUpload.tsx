import React, { useState } from 'react';
import { Upload, Button, Card, message } from 'antd';
import { motion } from 'framer-motion';
import { UploadCloud, ArrowLeft, ArrowRight, FileText, FileSpreadsheet, PieChart, File } from 'lucide-react';
import type { UploadFile } from 'antd/es/upload/interface';

interface DocumentUploadProps {
  data: any;
  onNext: (data: any) => void;
  onPrev: () => void;
}

const DocumentUpload: React.FC<DocumentUploadProps> = ({ data, onNext, onPrev }) => {
  const [fileList, setFileList] = useState<UploadFile[]>(data.files || []);

  const documentTypes = [
    {
      key: 'form16',
      title: 'Form 16',
      description: 'Annual salary statement from your employer',
      icon: <FileText className="h-6 w-6 text-blue-500" />
    },
    {
      key: 'bankStatement',
      title: 'Bank Statement',
      description: 'Statement showing your income and expenses',
      icon: <FileSpreadsheet className="h-6 w-6 text-blue-500" />
    },
    {
      key: 'capitalGains',
      title: 'Capital Gains Statement',
      description: 'Statement of profits/losses from investments',
      icon: <PieChart className="h-6 w-6 text-blue-500" />
    },
    {
      key: 'other',
      title: 'Other Documents',
      description: 'Any other relevant financial documents',
      icon: <File className="h-6 w-6 text-blue-500" />
    }
  ];

  const handleChange = ({ fileList: newFileList }: any) => {
    setFileList(newFileList);
  };

  const handleNext = () => {
    if (fileList.length === 0) {
      message.warning('Please upload at least one document');
      return;
    }
    onNext({ files: fileList });
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <div className="max-w-2xl mx-auto">
        <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">
          Upload Documents
        </h2>

        <div className="space-y-6">
          {documentTypes.map(({ key, title, description, icon }) => (
            <Card key={key} className="shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  {icon}
                </div>
                <div className="flex-grow">
                  <h3 className="text-lg font-medium mb-2">{title}</h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    {description}
                  </p>
                  <Upload
                    action="/api/upload" // Replace with your upload endpoint
                    listType="picture"
                    multiple={true}
                    onChange={handleChange}
                    className="w-full"
                  >
                    <Button 
                      icon={<UploadCloud className="h-5 w-5" />}
                      className="w-full"
                    >
                      Upload {title}
                    </Button>
                  </Upload>
                </div>
              </div>
            </Card>
          ))}

          <div className="flex justify-between pt-6">
            <Button 
              size="large"
              onClick={onPrev}
              icon={<ArrowLeft className="h-5 w-5" />}
            >
              Previous
            </Button>
            <Button 
              type="primary"
              size="large"
              onClick={handleNext}
              icon={<ArrowRight className="h-5 w-5" />}
            >
              Next Step
            </Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default DocumentUpload;