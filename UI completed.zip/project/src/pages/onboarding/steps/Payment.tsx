import React from 'react';
import { Card, Button, Radio, Space, Alert } from 'antd';
import { motion } from 'framer-motion';
import { CreditCard, Wallet, Ban as Bank, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface PaymentProps {
  data: any;
  itrType: string;
  onNext: (data: any) => void;
  onPrev: () => void;
}

const Payment: React.FC<PaymentProps> = ({ data, itrType, onNext, onPrev }) => {
  const navigate = useNavigate();
  
  const getPriceForITR = (type: string): number => {
    const prices: { [key: string]: number } = {
      'ITR 1': 299,
      'ITR 2': 1499,
      'ITR 3': 1999,
      'ITR 4': 799
    };
    return prices[type] || 299;
  };

  const price = getPriceForITR(itrType || 'ITR 1');

  const paymentMethods = [
    {
      key: 'card',
      title: 'Credit/Debit Card',
      description: 'Pay securely with your card',
      icon: <CreditCard className="h-6 w-6 text-blue-500" />
    },
    {
      key: 'upi',
      title: 'UPI',
      description: 'Pay using any UPI app',
      icon: <Wallet className="h-6 w-6 text-blue-500" />
    },
    {
      key: 'netbanking',
      title: 'Net Banking',
      description: 'Pay through your bank account',
      icon: <Bank className="h-6 w-6 text-blue-500" />
    }
  ];

  const handlePayment = async () => {
    // Implement payment logic here
    onNext({ status: 'completed', amount: price });
  };

  const handlePayLater = () => {
    onNext({ status: 'pending', amount: price });
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <div className="max-w-2xl mx-auto">
        <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">
          Complete Payment
        </h2>

        <Alert
          message="Payment Information"
          description="You can complete the payment now or choose to pay later. However, we'll start processing your ITR only after the payment is received."
          type="info"
          showIcon
          className="mb-8"
        />

        <Card className="mb-8">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-medium">Selected Plan</h3>
              <p className="text-gray-600 dark:text-gray-400">{itrType || 'ITR 1'} Filing</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600 dark:text-gray-400">Amount</p>
              <p className="text-2xl font-bold text-blue-600">₹{price}</p>
            </div>
          </div>
        </Card>

        <Card className="mb-8">
          <h3 className="text-lg font-medium mb-4">Select Payment Method</h3>
          <Radio.Group defaultValue="card" className="w-full">
            <Space direction="vertical" className="w-full">
              {paymentMethods.map(({ key, title, description, icon }) => (
                <Radio key={key} value={key} className="w-full">
                  <Card className="w-full cursor-pointer hover:border-blue-500">
                    <div className="flex items-center space-x-4">
                      <div className="flex-shrink-0">
                        {icon}
                      </div>
                      <div>
                        <h4 className="font-medium">{title}</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {description}
                        </p>
                      </div>
                    </div>
                  </Card>
                </Radio>
              ))}
            </Space>
          </Radio.Group>
        </Card>

        <div className="flex justify-between">
          <Button 
            size="large"
            onClick={onPrev}
            icon={<ArrowLeft className="h-5 w-5" />}
          >
            Previous
          </Button>
          <Space>
            <Button 
              size="large"
              onClick={handlePayLater}
            >
              Pay Later
            </Button>
            <Button 
              type="primary"
              size="large"
              onClick={handlePayment}
              className="px-8"
            >
              Pay ₹{price}
            </Button>
          </Space>
        </div>
      </div>
    </motion.div>
  );
};

export default Payment;