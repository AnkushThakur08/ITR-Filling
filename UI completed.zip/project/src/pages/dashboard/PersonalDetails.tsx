import React, { useState } from 'react';
import { Card, Descriptions, Button, Form, Input, DatePicker, Modal, message } from 'antd';
import { motion } from 'framer-motion';
import { Edit, Save } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout';
import dayjs from 'dayjs';

interface PersonalDetailsProps {
  darkMode: boolean;
  toggleTheme: () => void;
}

const PersonalDetails: React.FC<PersonalDetailsProps> = ({ darkMode, toggleTheme }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [form] = Form.useForm();

  // This would come from your user context/state
  const userDetails = {
    name: 'John Doe',
    email: 'john.doe@example.com',
    phone: '+91 9876543210',
    pan: 'ABCDE1234F',
    address: '123 Tax Street, Financial District',
    pincode: '400001',
    dateOfBirth: '1990-05-15'
  };

  const handleEdit = () => {
    form.setFieldsValue({
      ...userDetails,
      dateOfBirth: dayjs(userDetails.dateOfBirth)
    });
    setIsEditing(true);
  };

  const handleSave = async () => {
    try {
      const values = await form.validateFields();
      console.log('Updated values:', values);
      message.success('Details updated successfully');
      setIsEditing(false);
    } catch (error) {
      console.error('Validation failed:', error);
    }
  };

  return (
    <DashboardLayout darkMode={darkMode} toggleTheme={toggleTheme} title="Personal Details">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-8"
      >
        <div className="max-w-6xl mx-auto lg:ml-64 px-4">
          <Card
            title="Personal Information"
            extra={
              !isEditing ? (
                <Button type="primary" icon={<Edit size={16} />} onClick={handleEdit}>
                  Edit
                </Button>
              ) : (
                <Button type="primary" icon={<Save size={16} />} onClick={handleSave}>
                  Save
                </Button>
              )
            }
            className="shadow-md"
          >
            {!isEditing ? (
              <Descriptions column={1} bordered>
                <Descriptions.Item label="Full Name">{userDetails.name}</Descriptions.Item>
                <Descriptions.Item label="Email Address">{userDetails.email}</Descriptions.Item>
                <Descriptions.Item label="Phone Number">{userDetails.phone}</Descriptions.Item>
                <Descriptions.Item label="PAN Number">{userDetails.pan}</Descriptions.Item>
                <Descriptions.Item label="Address">{userDetails.address}</Descriptions.Item>
                <Descriptions.Item label="Pincode">{userDetails.pincode}</Descriptions.Item>
                <Descriptions.Item label="Date of Birth">
                  {dayjs(userDetails.dateOfBirth).format('DD/MM/YYYY')}
                </Descriptions.Item>
              </Descriptions>
            ) : (
              <Form
                form={form}
                layout="vertical"
                initialValues={{
                  ...userDetails,
                  dateOfBirth: dayjs(userDetails.dateOfBirth)
                }}
              >
                <Form.Item
                  name="name"
                  label="Full Name"
                  rules={[{ required: true, message: 'Please enter your name' }]}
                >
                  <Input />
                </Form.Item>
                <Form.Item
                  name="email"
                  label="Email Address"
                  rules={[
                    { required: true, message: 'Please enter your email' },
                    { type: 'email', message: 'Please enter a valid email' }
                  ]}
                >
                  <Input />
                </Form.Item>
                <Form.Item
                  name="phone"
                  label="Phone Number"
                  rules={[{ required: true, message: 'Please enter your phone number' }]}
                >
                  <Input />
                </Form.Item>
                <Form.Item
                  name="pan"
                  label="PAN Number"
                  rules={[
                    { required: true, message: 'Please enter your PAN number' },
                    {
                      pattern: /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/,
                      message: 'Please enter a valid PAN number'
                    }
                  ]}
                >
                  <Input className="uppercase" />
                </Form.Item>
                <Form.Item
                  name="address"
                  label="Address"
                  rules={[{ required: true, message: 'Please enter your address' }]}
                >
                  <Input.TextArea rows={3} />
                </Form.Item>
                <Form.Item
                  name="pincode"
                  label="Pincode"
                  rules={[
                    { required: true, message: 'Please enter your pincode' },
                    {
                      pattern: /^[1-9][0-9]{5}$/,
                      message: 'Please enter a valid 6-digit pincode'
                    }
                  ]}
                >
                  <Input maxLength={6} />
                </Form.Item>
                <Form.Item
                  name="dateOfBirth"
                  label="Date of Birth"
                  rules={[{ required: true, message: 'Please select your date of birth' }]}
                >
                  <DatePicker className="w-full" format="DD/MM/YYYY" />
                </Form.Item>
              </Form>
            )}
          </Card>
        </div>
      </motion.div>
    </DashboardLayout>
  );
};

export default PersonalDetails;