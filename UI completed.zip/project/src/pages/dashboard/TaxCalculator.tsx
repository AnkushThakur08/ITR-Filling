import React, { useState } from 'react';
import { Form, Input, Select, Button, Card, Statistic, Divider, Radio, Alert, Space, InputNumber, Tooltip } from 'antd';
import { motion } from 'framer-motion';
import { Calculator, IndianRupee, Info, TrendingDown, TrendingUp, HelpCircle } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout';

interface TaxCalculatorProps {
  darkMode: boolean;
  toggleTheme: () => void;
}

const { Option } = Select;

const TaxCalculator: React.FC<TaxCalculatorProps> = ({ darkMode, toggleTheme }) => {
  const [form] = Form.useForm();
  const [taxRegime, setTaxRegime] = useState<'old' | 'new'>('new');
  const [calculatedTax, setCalculatedTax] = useState<number | null>(null);
  const [taxSavings, setTaxSavings] = useState<number | null>(null);

  const deductions = [
    { label: '80C (PPF, ELSS, LIC, etc.)', max: 150000 },
    { label: '80D (Health Insurance)', max: 25000 },
    { label: '80E (Education Loan Interest)', max: 0 },
    { label: 'HRA', max: 0 },
    { label: 'Standard Deduction', max: 50000 },
    { label: 'NPS (80CCD)', max: 50000 },
  ];

  const calculateTax = (values: any) => {
    // This is a simplified tax calculation logic
    const income = values.income || 0;
    let tax = 0;

    if (taxRegime === 'new') {
      if (income <= 300000) {
        tax = 0;
      } else if (income <= 600000) {
        tax = (income - 300000) * 0.05;
      } else if (income <= 900000) {
        tax = 15000 + (income - 600000) * 0.1;
      } else if (income <= 1200000) {
        tax = 45000 + (income - 900000) * 0.15;
      } else if (income <= 1500000) {
        tax = 90000 + (income - 1200000) * 0.2;
      } else {
        tax = 150000 + (income - 1500000) * 0.3;
      }
    } else {
      // Old regime calculation
      const totalDeductions = Object.values(values.deductions || {}).reduce((a: number, b: number) => a + (b || 0), 0);
      const taxableIncome = Math.max(0, income - totalDeductions);

      if (taxableIncome <= 250000) {
        tax = 0;
      } else if (taxableIncome <= 500000) {
        tax = (taxableIncome - 250000) * 0.05;
      } else if (taxableIncome <= 1000000) {
        tax = 12500 + (taxableIncome - 500000) * 0.2;
      } else {
        tax = 112500 + (taxableIncome - 1000000) * 0.3;
      }
    }

    // Calculate cess
    const cess = tax * 0.04;
    const totalTax = tax + cess;

    setCalculatedTax(totalTax);
    // Calculate tax savings (difference between old and new regime)
    const otherRegimeTax = calculateOtherRegimeTax(values);
    setTaxSavings(Math.abs(totalTax - otherRegimeTax));
  };

  const calculateOtherRegimeTax = (values: any) => {
    // Simplified calculation for comparison
    const income = values.income || 0;
    let tax = 0;

    if (taxRegime === 'new') {
      // Calculate old regime tax
      const assumedDeductions = 200000; // Example assumed deductions
      const taxableIncome = Math.max(0, income - assumedDeductions);

      if (taxableIncome <= 250000) {
        tax = 0;
      } else if (taxableIncome <= 500000) {
        tax = (taxableIncome - 250000) * 0.05;
      } else if (taxableIncome <= 1000000) {
        tax = 12500 + (taxableIncome - 500000) * 0.2;
      } else {
        tax = 112500 + (taxableIncome - 1000000) * 0.3;
      }
    } else {
      // Calculate new regime tax
      if (income <= 300000) {
        tax = 0;
      } else if (income <= 600000) {
        tax = (income - 300000) * 0.05;
      } else if (income <= 900000) {
        tax = 15000 + (income - 600000) * 0.1;
      } else if (income <= 1200000) {
        tax = 45000 + (income - 900000) * 0.15;
      } else if (income <= 1500000) {
        tax = 90000 + (income - 1200000) * 0.2;
      } else {
        tax = 150000 + (income - 1500000) * 0.3;
      }
    }

    return tax + (tax * 0.04); // Including cess
  };

  return (
    <DashboardLayout darkMode={darkMode} toggleTheme={toggleTheme} title="Tax Calculator">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4 md:p-8"
      >
        <div className="max-w-6xl mx-auto lg:ml-64 px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Input Section */}
            <div className="lg:col-span-2">
              <Card 
                title={
                  <div className="flex items-center space-x-2">
                    <Calculator className="h-5 w-5 text-blue-500" />
                    <span>Income Tax Calculator (FY 2024-25)</span>
                  </div>
                }
                className="shadow-md"
              >
                <Form
                  form={form}
                  layout="vertical"
                  onFinish={calculateTax}
                  initialValues={{
                    regime: 'new',
                    income: 0,
                    deductions: {}
                  }}
                >
                  <div className="mb-6">
                    <Alert
                      message="Choose Tax Regime"
                      description="Select the tax regime that best suits your financial situation."
                      type="info"
                      showIcon
                      className="mb-4"
                    />
                    <Radio.Group 
                      value={taxRegime} 
                      onChange={e => setTaxRegime(e.target.value)}
                      className="w-full"
                    >
                      <Space direction="vertical" className="w-full">
                        <Card className="w-full cursor-pointer hover:border-blue-500">
                          <Radio value="new">
                            <div>
                              <span className="font-medium">New Tax Regime</span>
                              <p className="text-sm text-gray-500 mt-1">
                                Lower tax rates without deductions
                              </p>
                            </div>
                          </Radio>
                        </Card>
                        <Card className="w-full cursor-pointer hover:border-blue-500">
                          <Radio value="old">
                            <div>
                              <span className="font-medium">Old Tax Regime</span>
                              <p className="text-sm text-gray-500 mt-1">
                                Higher tax rates with deductions and exemptions
                              </p>
                            </div>
                          </Radio>
                        </Card>
                      </Space>
                    </Radio.Group>
                  </div>

                  <Form.Item
                    label="Annual Income"
                    name="income"
                    rules={[{ required: true, message: 'Please enter your annual income' }]}
                  >
                    <InputNumber
                      prefix={<IndianRupee size={16} />}
                      className="w-full"
                      size="large"
                      min={0}
                      step={1000}
                      formatter={value => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                      parser={value => value!.replace(/\₹\s?|(,*)/g, '')}
                    />
                  </Form.Item>

                  {taxRegime === 'old' && (
                    <>
                      <Divider>Deductions & Exemptions</Divider>
                      {deductions.map((deduction, index) => (
                        <Form.Item
                          key={index}
                          label={
                            <div className="flex items-center">
                              {deduction.label}
                              {deduction.max > 0 && (
                                <Tooltip title={`Maximum limit: ₹${deduction.max.toLocaleString()}`}>
                                  <HelpCircle size={16} className="ml-2 text-gray-400" />
                                </Tooltip>
                              )}
                            </div>
                          }
                          name={['deductions', deduction.label]}
                        >
                          <InputNumber
                            prefix={<IndianRupee size={16} />}
                            className="w-full"
                            max={deduction.max || undefined}
                            formatter={value => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                            parser={value => value!.replace(/\₹\s?|(,*)/g, '')}
                          />
                        </Form.Item>
                      ))}
                    </>
                  )}

                  <Button type="primary" htmlType="submit" size="large" block>
                    Calculate Tax
                  </Button>
                </Form>
              </Card>
            </div>

            {/* Results Section */}
            <div className="lg:col-span-1">
              <div className="space-y-6 sticky top-24">
                <Card className="shadow-md">
                  <Statistic
                    title={<span className="text-lg">Estimated Tax</span>}
                    value={calculatedTax || 0}
                    prefix={<IndianRupee size={24} className="mr-2 text-blue-500" />}
                    valueStyle={{ color: '#0EA5E9' }}
                  />
                  {calculatedTax !== null && (
                    <div className="mt-4">
                      <p className="text-sm text-gray-500">
                        Monthly Tax: ₹{Math.round(calculatedTax / 12).toLocaleString()}
                      </p>
                    </div>
                  )}
                </Card>

                {taxSavings !== null && taxSavings > 0 && (
                  <Card className="shadow-md">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-lg font-medium">Tax Savings</h3>
                        <p className="text-sm text-gray-500">
                          Compared to {taxRegime === 'new' ? 'old' : 'new'} regime
                        </p>
                      </div>
                      <div className="flex items-center text-green-500">
                        <TrendingDown size={20} className="mr-2" />
                        ₹{taxSavings.toLocaleString()}
                      </div>
                    </div>
                  </Card>
                )}

                <Card className="bg-blue-50 dark:bg-blue-900">
                  <div className="flex items-start space-x-3">
                    <Info className="h-5 w-5 text-blue-500 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-medium mb-2">Tax Saving Tips</h3>
                      <ul className="text-sm space-y-2 text-gray-600 dark:text-gray-300">
                        <li>• Invest in tax-saving instruments like PPF, ELSS</li>
                        <li>• Maximize your 80C deductions (up to ₹1.5L)</li>
                        <li>• Consider NPS for additional tax benefits</li>
                        <li>• Keep all investment proofs handy</li>
                      </ul>
                    </div>
                  </div>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </DashboardLayout>
  );
};

export default TaxCalculator;