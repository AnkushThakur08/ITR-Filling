import React, { useState } from 'react';
import { Card, Upload, Button, List, Tag, Space, message, Empty, Tabs, Modal, Input, Radio } from 'antd';
import { motion } from 'framer-motion';
import { UploadCloud, FileText, Trash2, Download, AlertCircle, MessageSquare, Phone } from 'lucide-react';
import type { UploadFile, UploadProps } from 'antd/es/upload/interface';
import DashboardLayout from '../../components/DashboardLayout';

const { TabPane } = Tabs;

interface DocumentCenterProps {
  darkMode: boolean;
  toggleTheme: () => void;
}

const DocumentCenter: React.FC<DocumentCenterProps> = ({ darkMode, toggleTheme }) => {
  const [fileList, setFileList] = useState<UploadFile[]>([
    {
      uid: '1',
      name: 'Form16.pdf',
      status: 'done',
      type: 'application/pdf',
    },
    {
      uid: '2',
      name: 'BankStatement.pdf',
      status: 'done',
      type: 'application/pdf',
    }
  ]);

  const [isQueryModalVisible, setIsQueryModalVisible] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<any>(null);
  const [queryText, setQueryText] = useState('');
  const [queryAction, setQueryAction] = useState<'query' | 'call'>('query');

  const documentTypes = [
    {
      title: 'Form 16',
      description: 'Annual salary statement from your employer',
      required: true,
      icon: <FileText className="h-8 w-8 text-blue-500" />
    },
    {
      title: 'Bank Statement',
      description: 'Statement showing your income and expenses',
      required: true,
      icon: <FileText className="h-8 w-8 text-blue-500" />
    },
    {
      title: 'Investment Proofs',
      description: 'Documents showing your investments and tax-saving instruments',
      required: false,
      icon: <FileText className="h-8 w-8 text-blue-500" />
    }
  ];

  // Mock data for admin uploaded documents
  const adminDocuments = [
    {
      id: 1,
      name: 'Computation_Sheet_v1.pdf',
      type: 'Computation Sheet',
      uploadDate: '2024-03-20',
      status: 'Pending Approval',
      size: '1.2 MB'
    },
    {
      id: 2,
      name: 'Final_ITR_2024.pdf',
      type: 'Final ITR',
      uploadDate: '2024-03-22',
      status: 'Uploaded',
      size: '2.1 MB'
    }
  ];

  const documentHistory = [
    {
      id: 1,
      documentName: 'Computation_Sheet_v1.pdf',
      type: 'Computation Sheet',
      date: '2024-03-20',
      action: 'Query Raised',
      query: 'Please check the HRA calculation',
      status: 'Pending'
    },
    {
      id: 2,
      documentName: 'Computation_Sheet_v2.pdf',
      type: 'Computation Sheet',
      date: '2024-03-22',
      action: 'Approved',
      status: 'Completed'
    }
  ];

  const handleDownload = (file: UploadFile) => {
    message.success(`Downloading ${file.name}`);
  };

  const handleDelete = (file: UploadFile) => {
    setFileList(prev => prev.filter(f => f.uid !== file.uid));
    message.success(`${file.name} deleted successfully`);
  };

  const uploadProps: UploadProps = {
    name: 'file',
    multiple: true,
    action: '/api/upload',
    onChange(info) {
      const { status } = info.file;
      if (status === 'done') {
        message.success(`${info.file.name} file uploaded successfully.`);
        setFileList(prev => [...prev, info.file]);
      } else if (status === 'error') {
        message.error(`${info.file.name} file upload failed.`);
      }
    },
    beforeUpload(file) {
      const isValidType = ['application/pdf', 'image/jpeg', 'image/png'].includes(file.type);
      if (!isValidType) {
        message.error('You can only upload PDF, JPG, or PNG files!');
      }
      return isValidType || Upload.LIST_IGNORE;
    },
    maxCount: 5,
    showUploadList: false
  };

  const handleApprove = (document: any) => {
    message.success(`${document.name} approved successfully`);
  };

  const handleRaiseQuery = (document: any) => {
    setSelectedDocument(document);
    setIsQueryModalVisible(true);
  };

  const handleQuerySubmit = () => {
    if (queryAction === 'query' && !queryText.trim()) {
      message.error('Please enter your query');
      return;
    }

    if (queryAction === 'query') {
      message.success('Query raised successfully');
    } else {
      message.success('Call request submitted');
    }

    setIsQueryModalVisible(false);
    setQueryText('');
    setQueryAction('query');
  };

  return (
    <DashboardLayout darkMode={darkMode} toggleTheme={toggleTheme} title="Document Center">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4 md:p-8"
      >
        <div className="max-w-6xl mx-auto lg:ml-64 px-4">
          <Tabs defaultActiveKey="1">
            <TabPane tab="My Documents" key="1">
              <Card title="Required Documents" className="mb-6 shadow-md">
                <div className="space-y-6">
                  {documentTypes.map((doc, index) => (
                    <div key={index} className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                      <div className="flex items-start space-x-4">
                        <div className="flex-shrink-0">
                          {doc.icon}
                        </div>
                        <div className="flex-grow">
                          <div className="flex items-center justify-between">
                            <h3 className="text-lg font-medium">{doc.title}</h3>
                            {doc.required && (
                              <Tag color="red">Required</Tag>
                            )}
                          </div>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                            {doc.description}
                          </p>
                          <Upload {...uploadProps} className="mt-3">
                            <Button 
                              type="primary" 
                              icon={<UploadCloud size={16} />}
                              className="w-full md:w-auto"
                            >
                              Upload {doc.title}
                            </Button>
                          </Upload>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              <Card title="Uploaded Documents" className="shadow-md">
                {fileList.length > 0 ? (
                  <div className="space-y-4">
                    {fileList.map(file => (
                      <div 
                        key={file.uid}
                        className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg"
                      >
                        <div className="flex items-center space-x-3">
                          <FileText className="h-6 w-6 text-blue-500" />
                          <div>
                            <p className="font-medium">{file.name}</p>
                            <p className="text-sm text-gray-500">
                              Uploaded on {new Date().toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button 
                            type="text" 
                            icon={<Download size={16} />}
                            onClick={() => handleDownload(file)}
                          />
                          <Button 
                            type="text" 
                            danger
                            icon={<Trash2 size={16} />}
                            onClick={() => handleDelete(file)}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <Empty
                    image={Empty.PRESENTED_IMAGE_SIMPLE}
                    description="No documents uploaded yet"
                  />
                )}
              </Card>
            </TabPane>

            <TabPane tab="Admin Documents" key="2">
              <Card title="Documents from Admin" className="shadow-md">
                <List
                  itemLayout="horizontal"
                  dataSource={adminDocuments}
                  renderItem={document => (
                    <List.Item
                      actions={[
                        <Space>
                          <Button 
                            type="text" 
                            icon={<Download size={16} />}
                            onClick={() => handleDownload(document)}
                          >
                            Download
                          </Button>
                          {document.type === 'Computation Sheet' && document.status === 'Pending Approval' && (
                            <>
                              <Button 
                                type="primary"
                                onClick={() => handleApprove(document)}
                              >
                                Approve
                              </Button>
                              <Button 
                                onClick={() => handleRaiseQuery(document)}
                              >
                                Raise Query
                              </Button>
                            </>
                          )}
                        </Space>
                      ]}
                    >
                      <List.Item.Meta
                        avatar={<FileText className="h-6 w-6 text-blue-500" />}
                        title={document.name}
                        description={
                          <Space direction="vertical">
                            <Space>
                              <span>{document.type}</span>
                              <span>•</span>
                              <span>{document.size}</span>
                              <span>•</span>
                              <span>Uploaded on {new Date(document.uploadDate).toLocaleDateString()}</span>
                            </Space>
                            <Tag color={document.status === 'Pending Approval' ? 'warning' : 'success'}>
                              {document.status}
                            </Tag>
                          </Space>
                        }
                      />
                    </List.Item>
                  )}
                />
              </Card>
            </TabPane>

            <TabPane tab="Document History" key="3">
              <Card className="shadow-md">
                <List
                  itemLayout="horizontal"
                  dataSource={documentHistory}
                  renderItem={history => (
                    <List.Item>
                      <List.Item.Meta
                        avatar={<FileText className="h-6 w-6 text-blue-500" />}
                        title={history.documentName}
                        description={
                          <Space direction="vertical">
                            <Space>
                              <span>{history.type}</span>
                              <span>•</span>
                              <span>{new Date(history.date).toLocaleDateString()}</span>
                            </Space>
                            <Space>
                              <Tag color={history.action === 'Approved' ? 'success' : 'warning'}>
                                {history.action}
                              </Tag>
                              {history.query && (
                                <span className="text-gray-500">Query: {history.query}</span>
                              )}
                            </Space>
                          </Space>
                        }
                      />
                    </List.Item>
                  )}
                />
              </Card>
            </TabPane>
          </Tabs>
        </div>
      </motion.div>

      <Modal
        title="Raise Query"
        open={isQueryModalVisible}
        onCancel={() => setIsQueryModalVisible(false)}
        onOk={handleQuerySubmit}
        okText={queryAction === 'query' ? 'Submit Query' : 'Request Call'}
      >
        <div className="space-y-4">
          <Radio.Group
            value={queryAction}
            onChange={e => setQueryAction(e.target.value)}
            className="mb-4"
          >
            <Radio value="query">Raise Query</Radio>
            <Radio value="call">Request Call</Radio>
          </Radio.Group>

          {queryAction === 'query' && (
            <Input.TextArea
              value={queryText}
              onChange={e => setQueryText(e.target.value)}
              placeholder="Enter your query here..."
              rows={4}
            />
          )}

          {queryAction === 'call' && (
            <div className="flex items-center text-gray-600 dark:text-gray-400">
              <Phone size={16} className="mr-2" />
              <span>Our team will call you on your registered mobile number</span>
            </div>
          )}
        </div>
      </Modal>
    </DashboardLayout>
  );
};

export default DocumentCenter;