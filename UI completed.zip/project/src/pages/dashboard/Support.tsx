import React, { useState } from 'react';
import { Card, Button, Modal, Input, Radio, Space, message } from 'antd';
import { motion } from 'framer-motion';
import { Phone, MessageSquare, Mail, Clock } from 'lucide-react';
import DashboardLayout from '../../components/DashboardLayout';
import useNotificationStore from '../../store/notificationStore';

interface SupportProps {
  darkMode: boolean;
  toggleTheme: () => void;
}

const Support: React.FC<SupportProps> = ({ darkMode, toggleTheme }) => {
  const [isCallbackModalVisible, setIsCallbackModalVisible] = useState(false);
  const [preferredTime, setPreferredTime] = useState<string>('');
  const { addNotification } = useNotificationStore();

  const handleRequestCallback = () => {
    if (!preferredTime) {
      message.error('Please select preferred time');
      return;
    }

    addNotification({
      title: 'Callback Request',
      message: `Your callback request for ${preferredTime} has been received. Our team will contact you shortly.`,
      type: 'success'
    });

    // Also notify admin
    // This would typically be handled by your backend
    console.log('Notifying admin about callback request');

    setIsCallbackModalVisible(false);
    setPreferredTime('');
    message.success('Callback request submitted successfully');
  };

  const handleDirectCall = () => {
    // Implement direct call logic
    message.info('Initiating call...');
  };

  return (
    <DashboardLayout darkMode={darkMode} toggleTheme={toggleTheme} title="Support">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4 md:p-8"
      >
        <div className="max-w-6xl mx-auto lg:ml-64 px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <Card className="shadow-md">
              <div className="flex items-start space-x-4">
                <Phone className="h-8 w-8 text-blue-500 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-semibold mb-2">Request Callback</h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    Schedule a callback at your preferred time. Our tax experts will contact you.
                  </p>
                  <Button 
                    type="primary"
                    onClick={() => setIsCallbackModalVisible(true)}
                    icon={<Clock size={18} />}
                  >
                    Schedule Callback
                  </Button>
                </div>
              </div>
            </Card>

            <Card className="shadow-md">
              <div className="flex items-start space-x-4">
                <MessageSquare className="h-8 w-8 text-green-500 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-semibold mb-2">Direct Call</h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    Connect with our support team immediately for urgent queries.
                  </p>
                  <Button 
                    type="primary"
                    onClick={handleDirectCall}
                    icon={<Phone size={18} />}
                  >
                    Call Now
                  </Button>
                </div>
              </div>
            </Card>
          </div>

          <Card title="Contact Information" className="shadow-md">
            <div className="space-y-6">
              <div className="flex items-center space-x-3">
                <Mail className="h-6 w-6 text-blue-500" />
                <div>
                  <h4 className="font-medium">Email Support</h4>
                  <p className="text-gray-600 dark:text-gray-400">support@taxease.in</p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <Phone className="h-6 w-6 text-blue-500" />
                <div>
                  <h4 className="font-medium">Phone Support</h4>
                  <p className="text-gray-600 dark:text-gray-400">+91 123 456 7890</p>
                </div>
              </div>

              <div className="border-t pt-6">
                <h4 className="font-medium mb-2">Support Hours</h4>
                <p className="text-gray-600 dark:text-gray-400">
                  Monday to Saturday: 9:00 AM - 6:00 PM
                </p>
                <p className="text-gray-600 dark:text-gray-400">
                  Sunday: Closed
                </p>
              </div>
            </div>
          </Card>
        </div>
      </motion.div>

      <Modal
        title="Schedule Callback"
        open={isCallbackModalVisible}
        onOk={handleRequestCallback}
        onCancel={() => setIsCallbackModalVisible(false)}
      >
        <div className="space-y-4">
          <p>Select your preferred time for callback:</p>
          <Radio.Group 
            value={preferredTime}
            onChange={e => setPreferredTime(e.target.value)}
          >
            <Space direction="vertical">
              <Radio value="morning">Morning (9 AM - 12 PM)</Radio>
              <Radio value="afternoon">Afternoon (12 PM - 3 PM)</Radio>
              <Radio value="evening">Evening (3 PM - 6 PM)</Radio>
            </Space>
          </Radio.Group>
        </div>
      </Modal>
    </DashboardLayout>
  );
};

export default Support;