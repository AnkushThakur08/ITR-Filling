import React from 'react';
import { Card, Row, Col, Statistic, Table, Tag, Button } from 'antd';
import { motion } from 'framer-motion';
import { Users, FileCheck, Clock, AlertCircle, IndianRupee, Download } from 'lucide-react';
import AdminLayout from '../../components/AdminLayout';

interface AdminDashboardProps {
  darkMode: boolean;
  toggleTheme: () => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ darkMode, toggleTheme }) => {
  const stats = [
    {
      title: 'Total Users',
      value: 1250,
      icon: <Users className="h-8 w-8 text-blue-500" />,
      trend: '+12%',
      trendUp: true
    },
    {
      title: 'Completed ITRs',
      value: 850,
      icon: <FileCheck className="h-8 w-8 text-green-500" />,
      trend: '+8%',
      trendUp: true
    },
    {
      title: 'Pending ITRs',
      value: 320,
      icon: <Clock className="h-8 w-8 text-yellow-500" />,
      trend: '-5%',
      trendUp: false
    },
    {
      title: 'Issues Reported',
      value: 12,
      icon: <AlertCircle className="h-8 w-8 text-red-500" />,
      trend: '-2%',
      trendUp: false
    }
  ];

  const recentITRs = [
    {
      id: '1',
      user: 'John Doe',
      type: 'ITR-1',
      status: 'Processing',
      date: '2024-03-15',
      amount: 1499
    },
    {
      id: '2',
      user: 'Jane Smith',
      type: 'ITR-2',
      status: 'Completed',
      date: '2024-03-14',
      amount: 2999
    },
    {
      id: '3',
      user: 'Mike Johnson',
      type: 'ITR-3',
      status: 'Pending',
      date: '2024-03-13',
      amount: 4999
    }
  ];

  const columns = [
    {
      title: 'User',
      dataIndex: 'user',
      key: 'user'
    },
    {
      title: 'Type',
      dataIndex: 'type',
      key: 'type',
      render: (type: string) => (
        <Tag color="blue">{type}</Tag>
      )
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status: string) => {
        const colors = {
          Processing: 'orange',
          Completed: 'green',
          Pending: 'red'
        };
        return (
          <Tag color={colors[status as keyof typeof colors]}>{status}</Tag>
        );
      }
    },
    {
      title: 'Date',
      dataIndex: 'date',
      key: 'date',
      render: (date: string) => new Date(date).toLocaleDateString()
    },
    {
      title: 'Amount',
      dataIndex: 'amount',
      key: 'amount',
      render: (amount: number) => (
        <div className="flex items-center">
          <IndianRupee size={14} className="mr-1" />
          {amount.toLocaleString()}
        </div>
      )
    },
    {
      title: 'Action',
      key: 'action',
      render: () => (
        <Button type="link" icon={<Download size={16} />}>
          Download
        </Button>
      )
    }
  ];

  return (
    <AdminLayout darkMode={darkMode} toggleTheme={toggleTheme} title="Dashboard">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4 md:p-8"
      >
        <div className="max-w-6xl px-4 mx-auto lg:ml-64">
  <Row gutter={[16, 16]}>
    {stats.map((stat, index) => (
      <Col xs={24} sm={12} lg={6} key={index}>
        <Card className="shadow-md">
          <div className="flex items-start justify-between">
            <div>

                      <p className="text-gray-600 dark:text-gray-400">{stat.title}</p>
                      <h3 className="text-2xl font-bold mt-2">{stat.value}</h3>
                      <p className={`text-sm mt-2 ${stat.trendUp ? 'text-green-500' : 'text-red-500'}`}>
                        {stat.trend} from last month
                      </p>
                    </div>
                    {stat.icon}
                  </div>
                </Card>
              </Col>
            ))}
          </Row>

          <Card 
            title="Recent ITR Filings"
            className="mt-8 shadow-md"
          >
            <Table 
              columns={columns} 
              dataSource={recentITRs}
              pagination={false}
              scroll={{ x: true }}
            />
          </Card>
        </div>
      </motion.div>
    </AdminLayout>
  );
};

export default AdminDashboard;