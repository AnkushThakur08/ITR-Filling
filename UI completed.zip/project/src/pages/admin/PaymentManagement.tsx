import React, { useState } from 'react';
import { Table, Card, Button, Tag, Input, Select, DatePicker, Space, Statistic, Row, Col } from 'antd';
import { motion } from 'framer-motion';
import { Search, Download, IndianRupee, TrendingUp, CreditCard, Wallet } from 'lucide-react';
import type { DatePickerProps } from 'antd';
import AdminLayout from '../../components/AdminLayout';

const { RangePicker } = DatePicker;

interface PaymentManagementProps {
  darkMode: boolean;
  toggleTheme: () => void;
}

const PaymentManagement: React.FC<PaymentManagementProps> = ({ darkMode, toggleTheme }) => {
  const [searchText, setSearchText] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');

  // Mock data - replace with actual API calls
  const payments = [
    {
      id: '1',
      user: 'John Doe',
      amount: 1499,
      status: 'completed',
      date: '2024-03-15',
      paymentMethod: 'Credit Card',
      itrType: 'ITR-2',
      transactionId: 'TXN123456'
    },
    {
      id: '2',
      user: 'Jane Smith',
      amount: 2999,
      status: 'pending',
      date: '2024-03-14',
      paymentMethod: 'UPI',
      itrType: 'ITR-3',
      transactionId: 'TXN123457'
    }
  ];

  const handleSearch = (value: string) => {
    setSearchText(value);
  };

  const handleFilter = (value: string) => {
    setFilterStatus(value);
  };

  const handleDateRangeChange: DatePickerProps['onChange'] = (dates, dateStrings) => {
    console.log('Selected Range:', dates);
    console.log('Formatted Range:', dateStrings);
  };

  const columns = [
    {
      title: 'Transaction ID',
      dataIndex: 'transactionId',
      key: 'transactionId',
      render: (text: string) => <span className="font-medium">{text}</span>
    },
    {
      title: 'User',
      dataIndex: 'user',
      key: 'user'
    },
    {
      title: 'Amount',
      dataIndex: 'amount',
      key: 'amount',
      render: (amount: number) => (
        <div className="flex items-center">
          <IndianRupee size={14} className="mr-1" />
          {amount.toLocaleString()}
        </div>
      )
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status: string) => {
        const colors = {
          completed: 'success',
          pending: 'warning',
          failed: 'error'
        };
        return (
          <Tag color={colors[status as keyof typeof colors]}>
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </Tag>
        );
      }
    },
    {
      title: 'Payment Method',
      dataIndex: 'paymentMethod',
      key: 'paymentMethod',
      render: (method: string) => (
        <Tag color="blue">{method}</Tag>
      )
    },
    {
      title: 'ITR Type',
      dataIndex: 'itrType',
      key: 'itrType',
      render: (type: string) => (
        <Tag color="purple">{type}</Tag>
      )
    },
    {
      title: 'Date',
      dataIndex: 'date',
      key: 'date',
      render: (date: string) => new Date(date).toLocaleDateString()
    },
    {
      title: 'Action',
      key: 'action',
      render: () => (
        <Button 
          type="text" 
          icon={<Download size={16} />}
        >
          Invoice
        </Button>
      )
    }
  ];

  return (
    <AdminLayout darkMode={darkMode} toggleTheme={toggleTheme} title="Payment Management">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4 md:p-8"
      >
        <div className="max-w-6xl mx-auto lg:ml-64 px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="shadow-md">
              <Statistic
                title={<span className="text-lg">Total Revenue</span>}
                value={4498}
                prefix={<IndianRupee size={24} className="mr-2 text-blue-500" />}
                valueStyle={{ color: '#0EA5E9' }}
              />
              <div className="mt-2 flex items-center text-green-500">
                <TrendingUp size={16} className="mr-1" />
                <span className="text-sm">+12% from last month</span>
              </div>
            </Card>

            <Card className="shadow-md">
              <Statistic
                title={<span className="text-lg">Card Payments</span>}
                value={1499}
                prefix={<CreditCard size={24} className="mr-2 text-purple-500" />}
                valueStyle={{ color: '#0EA5E9' }}
              />
              <div className="mt-2 flex items-center text-purple-500">
                <span className="text-sm">33% of total payments</span>
              </div>
            </Card>

            <Card className="shadow-md">
              <Statistic
                title={<span className="text-lg">UPI Payments</span>}
                value={2999}
                prefix={<Wallet size={24} className="mr-2 text-green-500" />}
                valueStyle={{ color: '#0EA5E9' }}
              />
              <div className="mt-2 flex items-center text-green-500">
                <span className="text-sm">67% of total payments</span>
              </div>
            </Card>
          </div>

          <Card className="shadow-md">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
              <div className="flex flex-col md:flex-row gap-4 flex-grow">
                <Input
                  placeholder="Search transactions..."
                  prefix={<Search className="text-gray-400" size={18} />}
                  onChange={e => handleSearch(e.target.value)}
                  className="w-full md:w-64"
                />
                <Select
                  defaultValue="all"
                  onChange={handleFilter}
                  className="w-full md:w-40"
                  options={[
                    { value: 'all', label: 'All Status' },
                    { value: 'completed', label: 'Completed' },
                    { value: 'pending', label: 'Pending' },
                    { value: 'failed', label: 'Failed' }
                  ]}
                />
                <RangePicker 
                  onChange={handleDateRangeChange}
                  className="w-full md:w-auto"
                />
              </div>
              <Button
                type="primary"
                icon={<Download size={18} />}
              >
                Export
              </Button>
            </div>

            <Table
              columns={columns}
              dataSource={payments}
              rowKey="id"
              scroll={{ x: true }}
              pagination={{
                total: payments.length,
                pageSize: 10,
                showSizeChanger: true,
                showQuickJumper: true
              }}
            />
          </Card>
        </div>
      </motion.div>
    </AdminLayout>
  );
};

export default PaymentManagement;