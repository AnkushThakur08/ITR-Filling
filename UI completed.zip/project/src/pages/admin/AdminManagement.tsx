import React, { useState } from 'react';
import { Table, Card, Button, Tag, Input, Modal, Form, message, Space, Statistic, Select } from 'antd';
import { motion } from 'framer-motion';
import { Search, UserPlus, Edit2, Trash2, Mail, Phone, FileText, User } from 'lucide-react';
import AdminLayout from '../../components/AdminLayout';

interface AdminManagementProps {
  darkMode: boolean;
  toggleTheme: () => void;
}

const AdminManagement: React.FC<AdminManagementProps> = ({ darkMode, toggleTheme }) => {
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [editingAdmin, setEditingAdmin] = useState<any>(null);
  const [form] = Form.useForm();

  // Mock admin data
  const admins = [
    {
      id: '1',
      name: 'Rahul Matta',
      email: 'rahul@taxease.in',
      phone: '+91 9876543210',
      role: 'admin',
      completedITR: 32,
      pendingITR: 13,
      itrTypeStats: {
        'ITR-1': 3,
        'ITR-2': 15,
        'ITR-3': 5,
        'ITR-4': 10
      },
      status: 'active'
    },
    {
      id: '2',
      name: 'Akshay Singh',
      email: 'akshay@taxease.in',
      phone: '+91 9876543211',
      role: 'admin',
      completedITR: 28,
      pendingITR: 10,
      itrTypeStats: {
        'ITR-1': 8,
        'ITR-2': 12,
        'ITR-3': 4,
        'ITR-4': 4
      },
      status: 'active'
    },
    {
      id: '3',
      name: 'Ankush Thakur',
      email: 'ankush@taxease.in',
      phone: '+91 9876543212',
      role: 'admin',
      completedITR: 35,
      pendingITR: 7,
      itrTypeStats: {
        'ITR-1': 10,
        'ITR-2': 8,
        'ITR-3': 12,
        'ITR-4': 5
      },
      status: 'active'
    }
  ];

  const handleAddAdmin = () => {
    setEditingAdmin(null);
    form.resetFields();
    setIsModalVisible(true);
  };

  const handleEditAdmin = (admin: any) => {
    setEditingAdmin(admin);
    form.setFieldsValue(admin);
    setIsModalVisible(true);
  };

  const handleModalOk = async () => {
    try {
      const values = await form.validateFields();
      if (editingAdmin) {
        message.success('Admin updated successfully');
      } else {
        message.success('Admin added successfully');
      }
      setIsModalVisible(false);
      form.resetFields();
      setEditingAdmin(null);
    } catch (error) {
      console.error('Validation failed:', error);
    }
  };

  const handleModalCancel = () => {
    setIsModalVisible(false);
    form.resetFields();
    setEditingAdmin(null);
  };

  const handleDeleteAdmin = (id: string) => {
    Modal.confirm({
      title: 'Delete Admin',
      content: 'Are you sure you want to delete this admin? This action cannot be undone.',
      okText: 'Yes, Delete',
      okType: 'danger',
      cancelText: 'No, Cancel',
      onOk() {
        message.success('Admin deleted successfully');
      }
    });
  };

  const columns = [
    {
      title: 'Name',
      dataIndex: 'name',
      key: 'name',
      render: (text: string) => <span className="font-medium">{text}</span>
    },
    {
      title: 'Email',
      dataIndex: 'email',
      key: 'email'
    },
    {
      title: 'Phone',
      dataIndex: 'phone',
      key: 'phone'
    },
    {
      title: 'ITR Statistics',
      key: 'itrStats',
      render: (text: string, record: any) => (
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Tag color="success">Completed: {record.completedITR}</Tag>
            <Tag color="warning">Pending: {record.pendingITR}</Tag>
          </div>
          <div className="text-sm text-gray-500">
            <div>ITR-1: {record.itrTypeStats['ITR-1']}</div>
            <div>ITR-2: {record.itrTypeStats['ITR-2']}</div>
            <div>ITR-3: {record.itrTypeStats['ITR-3']}</div>
            <div>ITR-4: {record.itrTypeStats['ITR-4']}</div>
          </div>
        </div>
      )
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status: string) => (
        <Tag color={status === 'active' ? 'success' : 'error'}>
          {status.charAt(0).toUpperCase() + status.slice(1)}
        </Tag>
      )
    },
    {
      title: 'Action',
      key: 'action',
      render: (_: any, record: any) => (
        <Space>
          <Button 
            type="text" 
            icon={<Edit2 size={16} />}
            onClick={() => handleEditAdmin(record)}
          />
          <Button 
            type="text" 
            danger 
            icon={<Trash2 size={16} />}
            onClick={() => handleDeleteAdmin(record.id)}
          />
        </Space>
      )
    }
  ];

  return (
    <AdminLayout darkMode={darkMode} toggleTheme={toggleTheme} title="Admin Management">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4 md:p-8"
      >
        <div className="max-w-6xl mx-auto lg:ml-64 px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <Card>
              <Statistic
                title="Total Admins"
                value={admins.length}
                valueStyle={{ color: '#1890ff' }}
              />
            </Card>
            <Card>
              <Statistic
                title="Active Admins"
                value={admins.filter(a => a.status === 'active').length}
                valueStyle={{ color: '#52c41a' }}
              />
            </Card>
          </div>

          <Card className="shadow-md">
            <div className="flex justify-between items-center mb-6">
              <Input.Search
                placeholder="Search admins..."
                className="max-w-xs"
              />
              <Button
                type="primary"
                icon={<UserPlus size={18} />}
                onClick={handleAddAdmin}
              >
                Add Admin
              </Button>
            </div>

            <Table
              columns={columns}
              dataSource={admins}
              rowKey="id"
              pagination={{
                total: admins.length,
                pageSize: 10,
                showSizeChanger: true,
                showQuickJumper: true
              }}
            />
          </Card>
        </div>
      </motion.div>

      <Modal
        title={editingAdmin ? "Edit Admin" : "Add New Admin"}
        open={isModalVisible}
        onOk={handleModalOk}
        onCancel={handleModalCancel}
        width={600}
      >
        <Form
          form={form}
          layout="vertical"
          className="mt-4"
        >
          <Form.Item
            name="name"
            label="Full Name"
            rules={[{ required: true, message: 'Please enter admin name' }]}
          >
            <Input prefix={<User className="text-gray-400" size={18} />} />
          </Form.Item>
          
          <Form.Item
            name="email"
            label="Email"
            rules={[
              { required: true, message: 'Please enter email' },
              { type: 'email', message: 'Please enter a valid email' }
            ]}
          >
            <Input prefix={<Mail className="text-gray-400" size={18} />} />
          </Form.Item>
          
          <Form.Item
            name="phone"
            label="Phone"
            rules={[{ required: true, message: 'Please enter phone number' }]}
          >
            <Input prefix={<Phone className="text-gray-400" size={18} />} />
          </Form.Item>
          
          <Form.Item
            name="status"
            label="Status"
            rules={[{ required: true, message: 'Please select status' }]}
          >
            <Select
              options={[
                { value: 'active', label: 'Active' },
                { value: 'inactive', label: 'Inactive' }
              ]}
            />
          </Form.Item>
        </Form>
      </Modal>
    </AdminLayout>
  );
};

export default AdminManagement;