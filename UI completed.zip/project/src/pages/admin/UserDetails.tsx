import React from 'react';
import { Card, Descriptions, Button, Tag, List, Space, message, Upload, Tabs, Modal, Input } from 'antd';
import { motion } from 'framer-motion';
import { Download, FileText, Mail, Phone, Calendar, MapPin, CreditCard, UploadCloud } from 'lucide-react';
import { useParams, useNavigate } from 'react-router-dom';
import AdminLayout from '../../components/AdminLayout';
import type { UploadFile } from 'antd/es/upload/interface';

const { TabPane } = Tabs;

interface UserDetailsProps {
  darkMode: boolean;
  toggleTheme: () => void;
}

const UserDetails: React.FC<UserDetailsProps> = ({ darkMode, toggleTheme }) => {
  const { id } = useParams();
  const navigate = useNavigate();

  // Mock user data - replace with API call
  const user = {
    id: '1',
    name: 'John Doe',
    email: 'john@example.com',
    phone: '+91 9876543210',
    pan: 'ABCDE1234F',
    address: '123 Tax Street, Financial District',
    pincode: '400001',
    dateOfBirth: '1990-05-15',
    itrType: 'ITR-2',
    status: 'active',
    currentStep: 3,
    registrationDate: '2024-03-15',
    lastLogin: '2024-03-20',
    documents: [
      {
        id: 1,
        name: 'Form 16.pdf',
        type: 'Form 16',
        uploadDate: '2024-03-16',
        size: '2.5 MB'
      },
      {
        id: 2,
        name: 'Bank Statement.pdf',
        type: 'Bank Statement',
        uploadDate: '2024-03-16',
        size: '1.8 MB'
      }
    ],
    adminDocuments: [
      {
        id: 1,
        name: 'Computation_Sheet_v1.pdf',
        type: 'Computation Sheet',
        uploadDate: '2024-03-20',
        status: 'Pending Approval',
        size: '1.2 MB'
      },
      {
        id: 2,
        name: 'Final_ITR_2024.pdf',
        type: 'Final ITR',
        uploadDate: '2024-03-22',
        status: 'Uploaded',
        size: '2.1 MB'
      }
    ],
    documentHistory: [
      {
        id: 1,
        documentName: 'Computation_Sheet_v1.pdf',
        type: 'Computation Sheet',
        date: '2024-03-20',
        action: 'Query Raised',
        query: 'Please check the HRA calculation',
        status: 'Pending'
      },
      {
        id: 2,
        documentName: 'Computation_Sheet_v2.pdf',
        type: 'Computation Sheet',
        date: '2024-03-22',
        action: 'Approved',
        status: 'Completed'
      }
    ]
  };

  const handleDownloadAll = () => {
    message.success('Downloading all documents...');
  };

  const handleUploadDocument = (info: any) => {
    if (info.file.status === 'done') {
      message.success(`${info.file.name} uploaded successfully`);
    } else if (info.file.status === 'error') {
      message.error(`${info.file.name} upload failed.`);
    }
  };

  const uploadProps = {
    name: 'file',
    action: '/api/upload',
    onChange: handleUploadDocument,
    multiple: true,
    showUploadList: true,
    accept: '.pdf,.doc,.docx',
  };

  return (
    <AdminLayout darkMode={darkMode} toggleTheme={toggleTheme} title="User Details">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4 md:p-8"
      >
        <div className="max-w-6xl mx-auto lg:ml-64 px-4">
          <div className="mb-6 flex justify-between items-center">
            <Button onClick={() => navigate('/admin/users')}>Back to Users</Button>
            <Button type="primary" onClick={handleDownloadAll} icon={<Download size={18} />}>
              Download All Documents
            </Button>
          </div>

          <Tabs defaultActiveKey="1" className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <TabPane tab="Personal Information" key="1">
              <Card className="mb-6">
                <Descriptions column={{ xs: 1, sm: 2, md: 3 }} bordered>
                  <Descriptions.Item label="Full Name">{user.name}</Descriptions.Item>
                  <Descriptions.Item label="Email">{user.email}</Descriptions.Item>
                  <Descriptions.Item label="Phone">{user.phone}</Descriptions.Item>
                  <Descriptions.Item label="PAN">{user.pan}</Descriptions.Item>
                  <Descriptions.Item label="Address">{user.address}</Descriptions.Item>
                  <Descriptions.Item label="Pincode">{user.pincode}</Descriptions.Item>
                  <Descriptions.Item label="Date of Birth">
                    {new Date(user.dateOfBirth).toLocaleDateString()}
                  </Descriptions.Item>
                  <Descriptions.Item label="ITR Type">
                    <Tag color="blue">{user.itrType}</Tag>
                  </Descriptions.Item>
                  <Descriptions.Item label="Status">
                    <Tag color={user.status === 'active' ? 'success' : 'warning'}>
                      {user.status.charAt(0).toUpperCase() + user.status.slice(1)}
                    </Tag>
                  </Descriptions.Item>
                </Descriptions>
              </Card>

              <Card title="User Documents" className="mb-6">
                <List
                  itemLayout="horizontal"
                  dataSource={user.documents}
                  renderItem={document => (
                    <List.Item
                      actions={[
                        <Button 
                          key="download"
                          type="text"
                          icon={<Download size={16} />}
                          onClick={() => message.success(`Downloading ${document.name}`)}
                        >
                          Download
                        </Button>
                      ]}
                    >
                      <List.Item.Meta
                        avatar={<FileText className="h-6 w-6 text-blue-500" />}
                        title={document.name}
                        description={
                          <Space>
                            <span>{document.type}</span>
                            <span>•</span>
                            <span>{document.size}</span>
                            <span>•</span>
                            <span>Uploaded on {new Date(document.uploadDate).toLocaleDateString()}</span>
                          </Space>
                        }
                      />
                    </List.Item>
                  )}
                />
              </Card>
            </TabPane>

            <TabPane tab="Admin Documents" key="2">
              <Card title="Upload Documents" className="mb-6">
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-4">Computation Sheet</h3>
                    <Upload {...uploadProps}>
                      <Button icon={<UploadCloud size={16} />}>Upload Computation Sheet</Button>
                    </Upload>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-4">Final ITR</h3>
                    <Upload {...uploadProps}>
                      <Button icon={<UploadCloud size={16} />}>Upload Final ITR</Button>
                    </Upload>
                  </div>
                </div>
              </Card>

              <Card title="Uploaded Documents">
                <List
                  itemLayout="horizontal"
                  dataSource={user.adminDocuments}
                  renderItem={document => (
                    <List.Item
                      actions={[
                        <Button 
                          key="download"
                          type="text"
                          icon={<Download size={16} />}
                          onClick={() => message.success(`Downloading ${document.name}`)}
                        >
                          Download
                        </Button>
                      ]}
                    >
                      <List.Item.Meta
                        avatar={<FileText className="h-6 w-6 text-blue-500" />}
                        title={document.name}
                        description={
                          <Space direction="vertical">
                            <Space>
                              <span>{document.type}</span>
                              <span>•</span>
                              <span>{document.size}</span>
                              <span>•</span>
                              <span>Uploaded on {new Date(document.uploadDate).toLocaleDateString()}</span>
                            </Space>
                            <Tag color={document.status === 'Pending Approval' ? 'warning' : 'success'}>
                              {document.status}
                            </Tag>
                          </Space>
                        }
                      />
                    </List.Item>
                  )}
                />
              </Card>
            </TabPane>

            <TabPane tab="Document History" key="3">
              <Card>
                <List
                  itemLayout="horizontal"
                  dataSource={user.documentHistory}
                  renderItem={history => (
                    <List.Item>
                      <List.Item.Meta
                        avatar={<FileText className="h-6 w-6 text-blue-500" />}
                        title={history.documentName}
                        description={
                          <Space direction="vertical">
                            <Space>
                              <span>{history.type}</span>
                              <span>•</span>
                              <span>{new Date(history.date).toLocaleDateString()}</span>
                            </Space>
                            <Space>
                              <Tag color={history.action === 'Approved' ? 'success' : 'warning'}>
                                {history.action}
                              </Tag>
                              {history.query && (
                                <span className="text-gray-500">Query: {history.query}</span>
                              )}
                            </Space>
                          </Space>
                        }
                      />
                    </List.Item>
                  )}
                />
              </Card>
            </TabPane>
          </Tabs>
        </div>
      </motion.div>
    </AdminLayout>
  );
};

export default UserDetails;