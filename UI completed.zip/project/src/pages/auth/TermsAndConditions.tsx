import React from 'react';
import { Card, Button, Checkbox, Form, message } from 'antd';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import useAuthStore from '../../store/authStore';

const TermsAndConditions: React.FC = () => {
  const navigate = useNavigate();
  const [form] = Form.useForm();

  const handleAccept = async () => {
    try {
      await form.validateFields();
      // Store acceptance in user profile/localStorage
      localStorage.setItem('termsAccepted', 'true');
      message.success('Terms & Conditions accepted');
      navigate('/onboarding');
    } catch (error) {
      console.error('Validation failed:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-12 px-4 sm:px-6 lg:px-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-4xl mx-auto"
      >
        <Card className="shadow-xl">
          <h1 className="text-3xl font-bold text-center mb-8">Terms & Conditions</h1>

          <div className="prose dark:prose-invert max-w-none mb-8">
            <h2>1. Acceptance of Terms</h2>
            <p>
              By accessing and using TaxEase's services, you agree to be bound by these Terms and Conditions.
              These terms govern your use of our income tax return filing services.
            </p>

            <h2>2. Service Description</h2>
            <p>
              TaxEase provides online income tax return filing services. We assist in preparing and filing
              your income tax returns based on the information you provide.
            </p>

            <h2>3. User Responsibilities</h2>
            <ul>
              <li>Provide accurate and complete information</li>
              <li>Maintain confidentiality of your account credentials</li>
              <li>Verify all information before final submission</li>
              <li>Comply with all applicable tax laws and regulations</li>
            </ul>

            <h2>4. Privacy & Data Protection</h2>
            <p>
              We implement appropriate security measures to protect your personal and financial information.
              Your data is handled in accordance with our Privacy Policy and applicable data protection laws.
            </p>

            <h2>5. Payment Terms</h2>
            <p>
              Our fees are clearly displayed before service initiation. Payment is required to complete
              the tax filing process. All fees are non-refundable unless specified otherwise.
            </p>

            <h2>6. Limitation of Liability</h2>
            <p>
              While we strive for accuracy, we are not liable for errors resulting from incorrect
              information provided by users. Users are responsible for verifying all calculations.
            </p>
          </div>

          <Form form={form}>
            <Form.Item
              name="agreement"
              valuePropName="checked"
              rules={[
                {
                  validator: (_, value) =>
                    value
                      ? Promise.resolve()
                      : Promise.reject(new Error('Please accept the terms and conditions')),
                },
              ]}
            >
              <Checkbox>
                I have read and agree to the Terms & Conditions
              </Checkbox>
            </Form.Item>

            <div className="flex justify-end space-x-4">
              <Button onClick={() => navigate(-1)}>
                Decline
              </Button>
              <Button type="primary" onClick={handleAccept}>
                Accept & Continue
              </Button>
            </div>
          </Form>
        </Card>
      </motion.div>
    </div>
  );
};

export default TermsAndConditions;