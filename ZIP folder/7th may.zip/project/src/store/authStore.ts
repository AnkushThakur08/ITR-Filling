import create from 'zustand';
import { AuthState, User } from '../types/auth';

const useAuthStore = create<AuthState>((set) => ({
  user: null,
  isAuthenticated: false,
  isLoading: false,
  error: null,

  setUser: (user: User | null) => set({ user, isAuthenticated: !!user }),
  setLoading: (isLoading: boolean) => set({ isLoading }),
  setError: (error: string | null) => set({ error }),
  logout: () => set({ user: null, isAuthenticated: false, error: null }),
}));

export default useAuthStore;