import React, { useState } from 'react';
import { Form, Radio, Button, Card, Space, Alert } from 'antd';
import { motion } from 'framer-motion';
import { Building2, Briefcase, Home, PiggyBank, Globe, Coins, ArrowRight, ArrowLeft } from 'lucide-react';

interface IncomeSourceProps {
  data: any;
  onNext: (data: any) => void;
  onPrev: () => void;
}

const IncomeSource: React.FC<IncomeSourceProps> = ({ data, onNext, onPrev }) => {
  const [form] = Form.useForm();
  const [selectedSources, setSelectedSources] = useState<string[]>(data.sources || []);

  const incomeQuestions = [
    {
      key: 'salary',
      question: 'Do you earn a salary from employment?',
      icon: <Building2 className="h-6 w-6 text-blue-500" />
    },
    {
      key: 'business',
      question: 'Do you have income from business or profession?',
      icon: <Briefcase className="h-6 w-6 text-blue-500" />
    },
    {
      key: 'rental',
      question: 'Do you earn rental income?',
      icon: <Home className="h-6 w-6 text-blue-500" />
    },
    {
      key: 'investment',
      question: 'Do you have income from investments (stocks, mutual funds, etc.)?',
      icon: <PiggyBank className="h-6 w-6 text-blue-500" />
    },
    {
      key: 'otherSources',
      question: 'Do you have income from other sources?',
      icon: <Coins className="h-6 w-6 text-blue-500" />
    },
    {
      key: 'foreignIncome',
      question: 'Do you have income from foreign sources?',
      icon: <Globe className="h-6 w-6 text-blue-500" />
    }
  ];

  const determineITRType = (sources: string[]): { type: string; price: number } => {
    if (sources.includes('business')) {
      return { type: 'ITR 3', price: 1999 };
    }
    if (sources.includes('investment') || sources.includes('rental') || sources.includes('foreignIncome')) {
      return { type: 'ITR 2', price: 1499 };
    }
    if (sources.includes('salary')) {
      return { type: 'ITR 1', price: 299 };
    }
    return { type: 'ITR 4', price: 799 }; // Default
  };

  const handleSourceChange = (source: string, value: string) => {
    const newSources = value === 'yes' 
      ? [...selectedSources, source]
      : selectedSources.filter(s => s !== source);
    
    setSelectedSources(newSources);
  };

  const handleSubmit = (values: any) => {
    const itrInfo = determineITRType(selectedSources);
    onNext({
      ...values,
      sources: selectedSources,
      itrType: itrInfo.type,
      price: itrInfo.price
    });
  };

  const itrInfo = determineITRType(selectedSources);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <div className="max-w-2xl mx-auto">
        <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">
          Income Sources
        </h2>
        
        <Form
          form={form}
          layout="vertical"
          initialValues={data}
          onFinish={handleSubmit}
          className="space-y-6"
        >
          {incomeQuestions.map(({ key, question, icon }) => (
            <Card key={key} className="shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  {icon}
                </div>
                <div className="flex-grow">
                  <p className="text-lg mb-4">{question}</p>
                  <Form.Item name={key} className="mb-0">
                    <Radio.Group 
                      onChange={(e) => handleSourceChange(key, e.target.value)}
                      defaultValue={selectedSources.includes(key) ? 'yes' : 'no'}
                    >
                      <Space direction="horizontal">
                        <Radio value="yes">Yes</Radio>
                        <Radio value="no">No</Radio>
                      </Space>
                    </Radio.Group>
                  </Form.Item>
                </div>
              </div>
            </Card>
          ))}

          {selectedSources.length > 0 && (
            <Alert
              message={`Based on your income sources, we recommend ${itrInfo.type}`}
              description={`The filing fee for this return type is ₹${itrInfo.price}`}
              type="info"
              showIcon
              className="mt-6"
            />
          )}

          <div className="flex justify-between pt-6">
            <Button 
              size="large"
              onClick={onPrev}
              icon={<ArrowLeft className="h-5 w-5" />}
            >
              Previous
            </Button>
            <Button 
              type="primary"
              size="large"
              htmlType="submit"
              icon={<ArrowRight className="h-5 w-5" />}
            >
              Next Step
            </Button>
          </div>
        </Form>
      </div>
    </motion.div>
  );
};

export default IncomeSource;