import React, { useState } from 'react';
import { Table, Card, Button, Tag, Input, Select, Modal, Form, message, Space } from 'antd';
import { motion } from 'framer-motion';
import { Search, UserPlus, Edit2, Trash2, Mail, Phone, Calendar, FileText, User } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import AdminLayout from '../../components/AdminLayout';

interface UserManagementProps {
  darkMode: boolean;
  toggleTheme: () => void;
}

const UserManagement: React.FC<UserManagementProps> = ({ darkMode, toggleTheme }) => {
  const navigate = useNavigate();
  const [searchText, setSearchText] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [editingUser, setEditingUser] = useState<any>(null);
  const [form] = Form.useForm();

  // Mock data - replace with actual API calls
  const users = [
    {
      id: '1',
      name: 'John Doe',
      email: 'john@example.com',
      phone: '+91 9876543210',
      status: 'active',
      itrType: 'ITR-1',
      registrationDate: '2024-03-15',
      lastLogin: '2024-03-20',
      currentStep: 3
    },
    {
      id: '2',
      name: 'Jane Smith',
      email: 'jane@example.com',
      phone: '+91 9876543211',
      status: 'pending',
      itrType: 'ITR-2',
      registrationDate: '2024-03-14',
      lastLogin: '2024-03-19',
      currentStep: 2
    }
  ];

  const handleSearch = (value: string) => {
    setSearchText(value);
  };

  const handleFilter = (value: string) => {
    setFilterStatus(value);
  };

  const handleAddUser = () => {
    setEditingUser(null);
    form.resetFields();
    setIsModalVisible(true);
  };

  const handleEditUser = (user: any) => {
    setEditingUser(user);
    form.setFieldsValue(user);
    setIsModalVisible(true);
  };

  const handleModalOk = async () => {
    try {
      const values = await form.validateFields();
      if (editingUser) {
        message.success('User updated successfully');
      } else {
        message.success('User added successfully');
      }
      setIsModalVisible(false);
      form.resetFields();
      setEditingUser(null);
    } catch (error) {
      console.error('Validation failed:', error);
    }
  };

  const handleModalCancel = () => {
    setIsModalVisible(false);
    form.resetFields();
    setEditingUser(null);
  };

  const handleDeleteUser = (id: string) => {
    Modal.confirm({
      title: 'Delete User',
      content: 'Are you sure you want to delete this user? This action cannot be undone.',
      okText: 'Yes, Delete',
      okType: 'danger',
      cancelText: 'No, Cancel',
      onOk() {
        message.success('User deleted successfully');
      }
    });
  };

  const getStepStatus = (step: number) => {
    const stepLabels = {
      1: 'Registration Completed',
      2: 'Income Source Selected',
      3: 'Documents Uploaded',
      4: 'Payment Completed'
    };
    return stepLabels[step as keyof typeof stepLabels] || 'Unknown';
  };

  const columns = [
    {
      title: 'Name',
      dataIndex: 'name',
      key: 'name',
      render: (text: string, record: any) => (
        <Button 
          type="link" 
          onClick={() => navigate(`/admin/users/${record.id}`)}
          className="font-medium p-0"
        >
          {text}
        </Button>
      )
    },
    {
      title: 'Email',
      dataIndex: 'email',
      key: 'email'
    },
    {
      title: 'Phone',
      dataIndex: 'phone',
      key: 'phone'
    },
    {
      title: 'ITR Type',
      dataIndex: 'itrType',
      key: 'itrType',
      render: (type: string) => (
        <Tag color="blue">{type}</Tag>
      )
    },
    {
      title: 'Current Step',
      dataIndex: 'currentStep',
      key: 'currentStep',
      render: (step: number) => (
        <div>
          <Tag color="purple">Step {step} of 4</Tag>
          <div className="text-xs text-gray-500 mt-1">{getStepStatus(step)}</div>
        </div>
      )
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status: string) => {
        const colors = {
          active: 'success',
          pending: 'warning',
          blocked: 'error'
        };
        return (
          <Tag color={colors[status as keyof typeof colors]}>
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </Tag>
        );
      }
    },
    {
      title: 'Registration Date',
      dataIndex: 'registrationDate',
      key: 'registrationDate',
      render: (date: string) => new Date(date).toLocaleDateString()
    },
    {
      title: 'Action',
      key: 'action',
      render: (_: any, record: any) => (
        <Space>
          <Button 
            type="text" 
            icon={<Edit2 size={16} />}
            onClick={() => handleEditUser(record)}
          />
          <Button 
            type="text" 
            danger 
            icon={<Trash2 size={16} />}
            onClick={() => handleDeleteUser(record.id)}
          />
          <Button 
            type="text"
            icon={<FileText size={16} />}
            onClick={() => navigate(`/admin/users/${record.id}`)}
          />
        </Space>
      )
    }
  ];

  return (
    <AdminLayout darkMode={darkMode} toggleTheme={toggleTheme} title="User Management">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4 md:p-8"
      >
        <div className="max-w-6xl mx-auto lg:ml-64 px-4">
          <Card className="shadow-md">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
              <div className="flex flex-col md:flex-row gap-4 flex-grow">
                <Input
                  placeholder="Search users..."
                  prefix={<Search className="text-gray-400" size={18} />}
                  onChange={e => handleSearch(e.target.value)}
                  className="w-full md:w-64"
                />
                <Select
                  defaultValue="all"
                  onChange={handleFilter}
                  className="w-full md:w-40"
                  options={[
                    { value: 'all', label: 'All Status' },
                    { value: 'active', label: 'Active' },
                    { value: 'pending', label: 'Pending' },
                    { value: 'blocked', label: 'Blocked' }
                  ]}
                />
              </div>
              <Button
                type="primary"
                icon={<UserPlus size={18} />}
                onClick={handleAddUser}
                className="w-full md:w-auto"
              >
                Add User
              </Button>
            </div>

            <Table
              columns={columns}
              dataSource={users}
              rowKey="id"
              scroll={{ x: true }}
              pagination={{
                total: users.length,
                pageSize: 10,
                showSizeChanger: true,
                showQuickJumper: true
              }}
            />
          </Card>
        </div>
      </motion.div>

      <Modal
        title={editingUser ? "Edit User" : "Add New User"}
        open={isModalVisible}
        onOk={handleModalOk}
        onCancel={handleModalCancel}
        width={600}
      >
        <Form
          form={form}
          layout="vertical"
          className="mt-4"
        >
          <Form.Item
            name="name"
            label="Full Name"
            rules={[{ required: true, message: 'Please enter user name' }]}
          >
            <Input prefix={<User className="text-gray-400" size={18} />} />
          </Form.Item>
          <Form.Item
            name="email"
            label="Email"
            rules={[
              { required: true, message: 'Please enter email' },
              { type: 'email', message: 'Please enter a valid email' }
            ]}
          >
            <Input prefix={<Mail className="text-gray-400" size={18} />} />
          </Form.Item>
          <Form.Item
            name="phone"
            label="Phone"
            rules={[{ required: true, message: 'Please enter phone number' }]}
          >
            <Input prefix={<Phone className="text-gray-400" size={18} />} />
          </Form.Item>
          <Form.Item
            name="itrType"
            label="ITR Type"
            rules={[{ required: true, message: 'Please select ITR type' }]}
          >
            <Select
              options={[
                { value: 'ITR-1', label: 'ITR-1' },
                { value: 'ITR-2', label: 'ITR-2' },
                { value: 'ITR-3', label: 'ITR-3' },
                { value: 'ITR-4', label: 'ITR-4' }
              ]}
            />
          </Form.Item>
          <Form.Item
            name="status"
            label="Status"
            rules={[{ required: true, message: 'Please select status' }]}
          >
            <Select
              options={[
                { value: 'active', label: 'Active' },
                { value: 'pending', label: 'Pending' },
                { value: 'blocked', label: 'Blocked' }
              ]}
            />
          </Form.Item>
        </Form>
      </Modal>
    </AdminLayout>
  );
};

export default UserManagement;