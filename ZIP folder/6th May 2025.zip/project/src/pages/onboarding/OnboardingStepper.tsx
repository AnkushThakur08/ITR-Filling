import React, { useState } from 'react';
import { Steps, message } from 'antd';
import { motion } from 'framer-motion';
import { FileText, User, DollarSign, Lock, CreditCard } from 'lucide-react';
import PersonalDetails from './steps/PersonalDetails';
import IncomeSource from './steps/IncomeSource';
import DocumentUpload from './steps/DocumentUpload';
import Credentials from './steps/Credentials';
import Payment from './steps/Payment';
import { useNavigate } from 'react-router-dom';

const OnboardingStepper: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({
    personalDetails: {},
    incomeSource: {},
    documents: [],
    credentials: {},
    payment: {}
  });
  
  const navigate = useNavigate();

  const steps = [
    {
      title: 'Personal Details',
      description: 'Basic information',
      icon: <User className="h-14 w-5" />,
      content: <PersonalDetails 
        data={formData.personalDetails} 
        onNext={(data) => handleNext(data, 0)}
      />
    },
    {
      title: 'Income Source',
      description: 'Select your sources',
      icon: <DollarSign className="h-14 w-5" />,
      content: <IncomeSource 
        data={formData.incomeSource} 
        onNext={(data) => handleNext(data, 1)}
        onPrev={() => setCurrentStep(currentStep - 1)}
      />
    },
    {
      title: 'Documents',
      description: 'Upload required files',
      icon: <FileText className="h-14 w-5" />,
      content: <DocumentUpload 
        data={formData.documents} 
        onNext={(data) => handleNext(data, 2)}
        onPrev={() => setCurrentStep(currentStep - 1)}
      />
    },
    {
      title: 'IT Portal',
      description: 'Optional credentials',
      icon: <Lock className="h-14 w-5" />,
      content: <Credentials 
        data={formData.credentials} 
        onNext={(data) => handleNext(data, 3)}
        onPrev={() => setCurrentStep(currentStep - 1)}
      />
    },
    {
      title: 'Payment',
      description: 'Complete registration',
      icon: <CreditCard className="h-14 w-5" />,
      content: <Payment 
        data={formData.payment}
        itrType={formData.incomeSource?.itrType}
        onNext={(data) => handleComplete(data)}
        onPrev={() => setCurrentStep(currentStep - 1)}
      />
    }
  ];

  const handleNext = (stepData: any, step: number) => {
    setFormData(prev => ({
      ...prev,
      [Object.keys(prev)[step]]: stepData
    }));
    setCurrentStep(currentStep + 1);
  };

  const handleComplete = async (paymentData: any) => {
    try {
      setFormData(prev => ({
        ...prev,
        payment: paymentData
      }));
      
      // Here you would typically send all the data to your backend
      console.log('Complete form data:', formData);
      
      message.success('Registration completed successfully!');
      navigate('/dashboard');
    } catch (error) {
      message.error('Something went wrong. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-12 px-4 sm:px-6 lg:px-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-4xl mx-auto"
      >
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 md:p-8">
          <Steps
            current={currentStep}
            items={steps.map(({ title, description, icon }) => ({
              title: <span className="text-sm font-medium">{title}</span>,
              description: <span className="text-xs">{description}</span>,
              icon: <div className="flex items-center justify-center">{icon}</div>
            }))}
            className="mb-8"
          />
          
          <div className="mt-8">
            {steps[currentStep].content}
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default OnboardingStepper;