import React from 'react';
import { Form, Input, Button, DatePicker } from 'antd';
import { motion } from 'framer-motion';
import { User, Mail, MapPin, CreditCard, Calendar } from 'lucide-react';

interface PersonalDetailsProps {
  data: any;
  onNext: (data: any) => void;
}

const PersonalDetails: React.FC<PersonalDetailsProps> = ({ data, onNext }) => {
  const [form] = Form.useForm();

  const handleSubmit = async (values: any) => {
    onNext(values);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <div className="max-w-2xl mx-auto">
        <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">
          Personal Details
        </h2>
        
        <Form
          form={form}
          layout="vertical"
          initialValues={data}
          onFinish={handleSubmit}
          className="space-y-6"
        >
          <Form.Item
            name="name"
            label="Full Name"
            rules={[{ required: true, message: 'Please enter your name' }]}
          >
            <Input 
              prefix={<User className="text-gray-400" size={18} />}
              placeholder="Enter your full name"
              size="large"
            />
          </Form.Item>

          <Form.Item
            name="email"
            label="Email Address"
            rules={[
              { required: true, message: 'Please enter your email' },
              { type: 'email', message: 'Please enter a valid email' }
            ]}
          >
            <Input 
              prefix={<Mail className="text-gray-400" size={18} />}
              placeholder="Enter your email address"
              size="large"
            />
          </Form.Item>

          <Form.Item
            name="address"
            label="Address"
            rules={[{ required: true, message: 'Please enter your address' }]}
          >
            <Input.TextArea 
              placeholder="Enter your complete address"
              size="large"
              rows={3}
              className="resize-none"
            />
          </Form.Item>

          <Form.Item
            name="pincode"
            label="Pincode"
            rules={[
              { required: true, message: 'Please enter your pincode' },
              { 
                pattern: /^[1-9][0-9]{5}$/,
                message: 'Please enter a valid 6-digit pincode'
              }
            ]}
          >
            <Input 
              prefix={<MapPin className="text-gray-400" size={18} />}
              placeholder="Enter your pincode"
              size="large"
              maxLength={6}
            />
          </Form.Item>

          <Form.Item
            name="pan"
            label="PAN Number"
            rules={[
              { required: true, message: 'Please enter your PAN number' },
              { 
                pattern: /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/,
                message: 'Please enter a valid PAN number'
              }
            ]}
          >
            <Input 
              prefix={<CreditCard className="text-gray-400" size={18} />}
              placeholder="Enter your PAN number"
              size="large"
              className="uppercase"
            />
          </Form.Item>

          <Form.Item
            name="dateOfBirth"
            label="Date of Birth"
            rules={[{ required: true, message: 'Please select your date of birth' }]}
          >
            <DatePicker 
              size="large"
              className="w-full"
              format="DD/MM/YYYY"
            />
          </Form.Item>

          <Form.Item className="mb-0">
            <Button 
              type="primary"
              size="large"
              htmlType="submit"
              className="w-full"
            >
              Next Step
            </Button>
          </Form.Item>
        </Form>
      </div>
    </motion.div>
  );
};

export default PersonalDetails;