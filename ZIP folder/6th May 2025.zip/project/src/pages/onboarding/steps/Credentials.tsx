import React from 'react';
import { Form, Input, Button, Alert } from 'antd';
import { motion } from 'framer-motion';
import { Lock, ArrowLeft, ArrowRight } from 'lucide-react';

interface CredentialsProps {
  data: any;
  onNext: (data: any) => void;
  onPrev: () => void;
}

const Credentials: React.FC<CredentialsProps> = ({ data, onNext, onPrev }) => {
  const [form] = Form.useForm();

  const handleSubmit = (values: any) => {
    onNext(values);
  };

  const handleSkip = () => {
    onNext({});
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <div className="max-w-2xl mx-auto">
        <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">
          Income Tax Portal Credentials
        </h2>

        <Alert
          message="This step is optional"
          description="Providing your Income Tax portal password will help us process your return faster. Your credentials are encrypted and secure."
          type="info"
          showIcon
          className="mb-8"
        />
        
        <Form
          form={form}
          layout="vertical"
          initialValues={data}
          onFinish={handleSubmit}
          className="space-y-6"
        >
          <Form.Item
            name="itPassword"
            label="Income Tax Portal Password"
            rules={[
              { 
                min: 8,
                message: 'Password must be at least 8 characters'
              }
            ]}
          >
            <Input.Password 
              prefix={<Lock className="text-gray-400" size={18} />}
              placeholder="Enter your Income Tax portal password"
              size="large"
            />
          </Form.Item>

          <div className="flex justify-between pt-6">
            <Button 
              size="large"
              onClick={onPrev}
              icon={<ArrowLeft className="h-5 w-5" />}
            >
              Previous
            </Button>
            <div className="space-x-4">
              <Button 
                size="large"
                onClick={handleSkip}
              >
                Skip this step
              </Button>
              <Button 
                type="primary"
                size="large"
                htmlType="submit"
                icon={<ArrowRight className="h-5 w-5" />}
              >
                Next Step
              </Button>
            </div>
          </div>
        </Form>
      </div>
    </motion.div>
  );
};

export default Credentials;