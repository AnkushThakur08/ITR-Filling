export interface TestimonialProps {
  id: number;
  name: string;
  role: string;
  company: string;
  testimonial: string;
  image: string;
}

export interface FAQItemProps {
  id: number;
  question: string;
  answer: string;
}

export interface FeatureItemProps {
  id: number;
  title: string;
  description: string;
  icon: React.ReactNode;
}

export interface WhyChooseUsItemProps {
  id: number;
  title: string;
  description: string;
  icon: React.ReactNode;
}