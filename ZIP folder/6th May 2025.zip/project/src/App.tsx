import React, { useState } from 'react';
import { ConfigProvider, theme } from 'antd';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from 'react-query';
import Navbar from './components/Navbar';
import Header from './components/Header';
import Hero from './components/Hero';
import Features from './components/Features';
import WhyChooseUs from './components/WhyChooseUs';
import Testimonials from './components/Testimonials';
import FAQ from './components/FAQ';
import Footer from './components/Footer';
import Login from './pages/auth/Login';
import Signup from './pages/auth/Signup';
import AdminLogin from './pages/admin/AdminLogin';
import AdminDashboard from './pages/admin/AdminDashboard';
import UserManagement from './pages/admin/UserManagement';
import PaymentManagement from './pages/admin/PaymentManagement';
import OnboardingStepper from './pages/onboarding/OnboardingStepper';
import Dashboard from './pages/dashboard/Dashboard';
import PersonalDetails from './pages/dashboard/PersonalDetails';
import DocumentCenter from './pages/dashboard/DocumentCenter';
import Payments from './pages/dashboard/Payments';
import Settings from './pages/dashboard/Settings';
import TaxCalculator from './pages/dashboard/TaxCalculator';
import './index.css';

const queryClient = new QueryClient();

const App: React.FC = () => {
  const [darkMode, setDarkMode] = useState<boolean>(false);
  
  const toggleTheme = () => {
    setDarkMode(!darkMode);
  };
  
  return (
    <QueryClientProvider client={queryClient}>
      <ConfigProvider
        theme={{
          algorithm: darkMode ? theme.darkAlgorithm : theme.defaultAlgorithm,
          token: {
            colorPrimary: '#0EA5E9',
            borderRadius: 8,
          },
        }}
      >
        <Router>
          <div className={darkMode ? 'dark' : 'light'}>
            <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 transition-colors duration-300">
              <Routes>
                <Route 
                  path="/" 
                  element={
                    <>
                      <Navbar darkMode={darkMode} toggleTheme={toggleTheme} />
                      <Header />
                      <main>
                        <Hero />
                        <Features />
                        <WhyChooseUs />
                        <Testimonials />
                        <FAQ />
                      </main>
                      <Footer />
                    </>
                  } 
                />
                <Route path="/login" element={<Login />} />
                <Route path="/signup" element={<Signup />} />
                <Route path="/admin/login" element={<AdminLogin />} />
                <Route path="/admin/dashboard" element={<AdminDashboard darkMode={darkMode} toggleTheme={toggleTheme} />} />
                {/* <Route path="/admin/users" element={<UserManagement darkMode={darkMode} toggleTheme={toggleTheme} />} /> */}
                {/* <Route path="/admin/payments" element={<PaymentManagement darkMode={darkMode} toggleTheme={toggleTheme} />} /> */}
                <Route path="/onboarding" element={<OnboardingStepper />} />
                <Route path="/dashboard" element={<Dashboard darkMode={darkMode} toggleTheme={toggleTheme} />} />
                <Route path="/dashboard/personal" element={<PersonalDetails darkMode={darkMode} toggleTheme={toggleTheme} />} />
                <Route path="/dashboard/documents" element={<DocumentCenter darkMode={darkMode} toggleTheme={toggleTheme} />} />
                <Route path="/dashboard/payments" element={<Payments darkMode={darkMode} toggleTheme={toggleTheme} />} />
                <Route path="/dashboard/calculator" element={<TaxCalculator darkMode={darkMode} toggleTheme={toggleTheme} />} />
                <Route path="/dashboard/settings" element={<Settings darkMode={darkMode} toggleTheme={toggleTheme} />} />
              </Routes>
            </div>
          </div>
        </Router>
      </ConfigProvider>
    </QueryClientProvider>
  );
};

export default App;