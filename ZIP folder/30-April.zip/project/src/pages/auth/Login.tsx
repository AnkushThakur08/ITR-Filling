import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { motion } from 'framer-motion';
import { Button, Input, message } from 'antd';
import { Phone, Lock, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { LoginFormData } from '../../types/auth';

const schema = yup.object().shape({
  phone: yup
    .string()
    .matches(/^[6-9]\d{9}$/, 'Please enter a valid Indian mobile number')
    .required('Phone number is required'),
  otp: yup
    .string()
    .matches(/^\d{6}$/, 'OTP must be 6 digits')
    .required('OTP is required'),
});

const Login: React.FC = () => {
  const [isOtpSent, setIsOtpSent] = useState(false);
  const { register, handleSubmit, watch, formState: { errors } } = useForm<LoginFormData>({
    resolver: yupResolver(schema),
  });

  const handleSendOtp = async () => {
    const phone = watch('phone');
    if (!phone || !/^[6-9]\d{9}$/.test(phone)) {
      message.error('Please enter a valid phone number');
      return;
    }
    
    try {
      // Implement OTP sending logic here
      setIsOtpSent(true);
      message.success('OTP sent successfully!');
    } catch (error) {
      message.error('Failed to send OTP. Please try again.');
    }
  };

  const onSubmit = async (data: LoginFormData) => {
    try {
      // Implement login logic here
      console.log('Login data:', data);
      message.success('Login successful!');
    } catch (error) {
      message.error('Login failed. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full"
      >
        <Link 
          to="/" 
          className="inline-flex items-center text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 mb-6"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back to Home
        </Link>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-xl p-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Welcome Back</h2>
            <p className="text-gray-600 dark:text-gray-300 mt-2">
              Login to manage your ITR filing
            </p>
          </div>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-2">
                Phone Number
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <Input
                  {...register('phone')}
                  className="pl-10"
                  placeholder="Enter your phone number"
                  size="large"
                  disabled={isOtpSent}
                />
              </div>
              {errors.phone && (
                <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.phone.message}</p>
              )}
            </div>

            {!isOtpSent ? (
              <Button
                type="primary"
                size="large"
                block
                onClick={handleSendOtp}
                className="h-12"
              >
                Send OTP
              </Button>
            ) : (
              <>
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-200">
                      Enter OTP
                    </label>
                    <button 
                      type="button"
                      onClick={() => setIsOtpSent(false)}
                      className="text-sm text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
                    >
                      Change Number
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                    <Input
                      {...register('otp')}
                      className="pl-10"
                      placeholder="Enter 6-digit OTP"
                      size="large"
                      maxLength={6}
                    />
                  </div>
                  {errors.otp && (
                    <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.otp.message}</p>
                  )}
                  <button 
                    type="button"
                    onClick={handleSendOtp}
                    className="mt-2 text-sm text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
                  >
                    Resend OTP
                  </button>
                </div>

                <Button 
                  type="primary" 
                  size="large" 
                  block 
                  htmlType="submit"
                  className="h-12"
                >
                  Login
                </Button>
              </>
            )}
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Don't have an account?{' '}
              <Link 
                to="/signup" 
                className="text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 font-medium"
              >
                Sign up
              </Link>
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default Login;