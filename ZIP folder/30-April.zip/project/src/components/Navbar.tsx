import React, { useState, useEffect } from 'react';
import { Button, Drawer, Space } from 'antd';
import { Sun, Moon, Menu, X } from 'lucide-react';
import { Link } from 'react-router-dom';

interface NavbarProps {
  darkMode: boolean;
  toggleTheme: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ darkMode, toggleTheme }) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#' },
    { name: 'Features', href: '#features' },
    { name: 'Pricing', href: '#pricing' },
  ];

  return (
    <nav
      className={`fixed w-full z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-white dark:bg-gray-800 shadow-md py-2'
          : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex-shrink-0 flex items-center">
            <Link to="/" className="text-2xl font-bold text-blue-600 dark:text-blue-400">
              TaxEase
            </Link>
          </div>
          
          {/* Desktop navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-center space-x-8">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="font-medium hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                >
                  {link.name}
                </a>
              ))}
            </div>
          </div>
          
          <div className="hidden md:flex items-center space-x-4">
            <Link to="/login">
              <Button 
                type="default"
                className="rounded-md"
              >
                Login
              </Button>
            </Link>
            <Link to="/signup">
              <Button 
                type="primary"
                className="rounded-md"
              >
                Sign Up
              </Button>
            </Link>
            <Button
              type="text"
              icon={darkMode ? <Sun size={20} /> : <Moon size={20} />}
              onClick={toggleTheme}
              className="flex items-center justify-center"
              aria-label="Toggle theme"
            />
          </div>
          
          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <Button
              type="text"
              icon={darkMode ? <Sun size={20} /> : <Moon size={20} />}
              onClick={toggleTheme}
              className="mr-2"
              aria-label="Toggle theme"
            />
            <Button
              type="text"
              icon={<Menu size={24} />}
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Open menu"
            />
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      <Drawer
        placement="right"
        onClose={() => setMobileMenuOpen(false)}
        open={mobileMenuOpen}
        width={300}
        closeIcon={<X size={24} />}
        title="Menu"
        bodyStyle={{ padding: 0 }}
      >
        <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="block px-3 py-4 text-base font-medium hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md"
              onClick={() => setMobileMenuOpen(false)}
            >
              {link.name}
            </a>
          ))}
          <Space direction="vertical" size="middle" className="w-full px-3 pt-4">
            <Link to="/login" onClick={() => setMobileMenuOpen(false)}>
              <Button type="default" block>
                Login
              </Button>
            </Link>
            <Link to="/signup" onClick={() => setMobileMenuOpen(false)}>
              <Button type="primary" block>
                Sign Up
              </Button>
            </Link>
          </Space>
        </div>
      </Drawer>
    </nav>
  );
};

export default Navbar;