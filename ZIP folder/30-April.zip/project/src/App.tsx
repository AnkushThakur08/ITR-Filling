import React, { useState } from 'react';
import { ConfigProvider, theme } from 'antd';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from 'react-query';
import Navbar from './components/Navbar';
import Header from './components/Header';
import Hero from './components/Hero';
import Features from './components/Features';
import WhyChooseUs from './components/WhyChooseUs';
import Testimonials from './components/Testimonials';
import FAQ from './components/FAQ';
import Footer from './components/Footer';
import Login from './pages/auth/Login';
import Signup from './pages/auth/Signup';
import './index.css';

const queryClient = new QueryClient();

const App: React.FC = () => {
  const [darkMode, setDarkMode] = useState<boolean>(false);
  
  const toggleTheme = () => {
    setDarkMode(!darkMode);
  };
  
  return (
    <QueryClientProvider client={queryClient}>
      <ConfigProvider
        theme={{
          algorithm: darkMode ? theme.darkAlgorithm : theme.defaultAlgorithm,
          token: {
            colorPrimary: '#0EA5E9',
            borderRadius: 8,
          },
        }}
      >
        <Router>
          <div className={darkMode ? 'dark' : 'light'}>
            <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 transition-colors duration-300">
              <Routes>
                <Route 
                  path="/" 
                  element={
                    <>
                      <Navbar darkMode={darkMode} toggleTheme={toggleTheme} />
                      <Header />
                      <main>
                        <Hero />
                        <Features />
                        <WhyChooseUs />
                        <Testimonials />
                        <FAQ />
                      </main>
                      <Footer />
                    </>
                  } 
                />
                <Route path="/login" element={<Login />} />
                <Route path="/signup" element={<Signup />} />
              </Routes>
            </div>
          </div>
        </Router>
      </ConfigProvider>
    </QueryClientProvider>
  );
};

export default App;